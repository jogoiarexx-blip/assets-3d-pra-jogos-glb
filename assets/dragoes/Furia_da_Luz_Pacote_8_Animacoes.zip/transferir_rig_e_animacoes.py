#!/usr/bin/env python3
"""Transfere rig de 49 ossos + 8 clips de um GLB animado para dragao nao rigado.
Preserva a MALHA e todas as texturas do alvo. Emprega correspondencia espacial,
normais e pesos interpolados, ja que as topologias dos GLBs nao coincidem.

Uso: python transferir_rig_e_animacoes.py noite_animada.glb branco_sem_rig.glb saida.glb
Dependencias: numpy, scipy. Procedimento direcionado aos dois arquivos anexados,
com alinhamento medido das formas originais e verificacao de compatibilidade.
"""
from pathlib import Path
import collections
import copy
import json
import sys
import struct
import numpy as np
from scipy.spatial import cKDTree

INPUT_RIG=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/mnt/data/Furia_da_Noite_8_Animacoes.glb')
INPUT_MESH=Path(sys.argv[2]) if len(sys.argv)>2 else Path('/mnt/data/firoa da luz.glb')
OUTPUT=Path(sys.argv[3]) if len(sys.argv)>3 else Path('/mnt/data/Furia_da_Luz_8_Animacoes_Rig49.glb')
REPORT=OUTPUT.with_suffix('.json')
ALIGNMENT=np.array([2.53726369,2.25968868,2.62903316,-0.00942217,0.85958796,-0.10037856],dtype=np.float64)

def read_glb(path):
    with open(path,'rb') as f:
        h=f.read(12); mag,ver,length=struct.unpack('<III',h)
        assert mag==0x46546c67 and ver==2 and length==path.stat().st_size
        jlen,jtype=struct.unpack('<II',f.read(8)); assert jtype==0x4e4f534a
        data=json.loads(f.read(jlen).decode('utf8'))
        blen,btype=struct.unpack('<II',f.read(8)); assert btype==0x004e4942
        binary=f.read(blen)
    return data,binary

def get_array(g,b,ai):
    a=g['accessors'][ai];v=g['bufferViews'][a['bufferView']]
    dtype=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']])
    width={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
    start=v.get('byteOffset',0)+a.get('byteOffset',0)
    stride=v.get('byteStride',dtype.itemsize*width)
    if stride==dtype.itemsize*width:
        return np.frombuffer(b,dtype=dtype,count=a['count']*width,offset=start).reshape((-1,width)).copy()
    return np.stack([np.frombuffer(b,dtype=dtype,count=width,offset=start+i*stride) for i in range(a['count'])])

def set_array(g,b,ai,arr):
    a=g['accessors'][ai];v=g['bufferViews'][a['bufferView']]
    dtype=np.dtype({5121:'u1',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']])
    arr=np.ascontiguousarray(arr,dtype=dtype)
    assert arr.size==a['count']*{'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
    start=v.get('byteOffset',0)+a.get('byteOffset',0)
    width=arr.shape[1]; stride=v.get('byteStride',dtype.itemsize*width)
    if stride==dtype.itemsize*width:b[start:start+arr.nbytes]=arr.tobytes()
    else:
        for i,row in enumerate(arr):b[start+i*stride:start+i*stride+row.nbytes]=row.tobytes()
    if 'min' in a:a['min']=np.min(arr,axis=0).astype(float).tolist()
    if 'max' in a:a['max']=np.max(arr,axis=0).astype(float).tolist()

def transfer_joints(night_pos,night_normal,night_joints,night_weights,light_pos,light_normal):
    # Reprojecta pele atraves da vizinhanca normal-aware. Nao pressupoe o mesmo
    # numero ou ordem de vertices, e evita misturar a frente e o verso das asas.
    kd=cKDTree(night_pos)
    k=12
    ids=[];ds=[]
    for sl in range(0,len(light_pos),14000):
        d,i=kd.query(light_pos[sl:sl+14000],k=k,workers=-1)
        ids.append(i);ds.append(d)
    ids=np.concatenate(ids).astype(np.int32)
    d=np.concatenate(ds).astype(np.float32)
    norms=np.maximum(0,np.sum(light_normal[:,None,:]*night_normal[ids],axis=2))
    # Kernel local conservador; superficie coincidente favorece vertices mais proximos.
    radius=np.maximum(.024,d[:,[3]]*1.25)
    proximity=1/(d**2+.012**2)
    normal_affinity=(.15 + .85*norms**2)
    closeness=np.exp(-.45*(d/radius)**2)
    neigh_w=proximity*normal_affinity*closeness
    neigh_w/=neigh_w.sum(axis=1,keepdims=True)
    # Juntas de cada vizinho (12 x 4); agrupa contribuicao global por osso.
    joint_weights=np.zeros((len(light_pos),49),dtype=np.float32)
    batch=np.arange(len(light_pos),dtype=np.int32)
    for ki in range(k):
        for ji in range(4):
            np.add.at(joint_weights,(batch,night_joints[ids[:,ki],ji].astype(np.int32)),
                      neigh_w[:,ki]*night_weights[ids[:,ki],ji])
    jj=np.argpartition(joint_weights,-4,axis=1)[:,-4:]
    ww=np.take_along_axis(joint_weights,jj,axis=1)
    order=np.argsort(ww,axis=1)[:,::-1]
    jj=np.take_along_axis(jj,order,axis=1).astype(np.uint8)
    ww=np.take_along_axis(ww,order,axis=1)
    ww/=np.maximum(1e-8,ww.sum(axis=1,keepdims=True))
    # Evita erros de soma e bone indexes fora de limites.
    assert np.max(np.abs(np.sum(ww,axis=1)-1))<2e-6
    return jj,ww,d[:,0],np.max(ww,axis=1)

def main():
    ng,nb=read_glb(INPUT_RIG); lg,lb=read_glb(INPUT_MESH)
    assert len(ng.get('skins',[]))==1 and len(ng['skins'][0]['joints'])==49
    assert [x['name'] for x in ng['animations']]==['Idle','Walk','Fly','Glide','Attack','Hurt','Takeoff','Landing']
    assert not lg.get('skins') and len(lg['meshes'])==1 and len(lg['meshes'][0]['primitives'])==1
    npr=ng['meshes'][0]['primitives'][0]
    lpr=lg['meshes'][0]['primitives'][0]
    na=npr['attributes'];la=lpr['attributes']
    original_pos=get_array(lg,lb,la['POSITION']); original_norm=get_array(lg,lb,la['NORMAL'])
    npos=get_array(ng,nb,na['POSITION'])
    nnorm=get_array(ng,nb,na['NORMAL'])
    nweights=get_array(ng,nb,na['WEIGHTS_0'])
    njoints=get_array(ng,nb,na['JOINTS_0'])
    # Orientacao preservada; escala e deslocamento alinham o branco ao bind pose preto.
    sx,sy,sz,tx,ty,tz=ALIGNMENT
    scales=ALIGNMENT[:3]; offs=ALIGNMENT[3:]
    pos=original_pos*scales+offs
    norm=original_norm/scales
    norm/=np.maximum(1e-12,np.linalg.norm(norm,axis=1,keepdims=True))
    joints,weights,closest,dominance=transfer_joints(npos,nnorm,njoints,nweights,pos,norm)

    # Preserva buffers da geometria ORIGINAL BRANCA, incluindo todos triangulos,
    # UV e imagens. Atualiza somente POSITION / NORMAL por transformacao global.
    out=bytearray(lb)
    set_array(lg,out,la['POSITION'],pos)
    set_array(lg,out,la['NORMAL'],norm)
    while len(out)%4:out.append(0)

    def append_block(raw,target=None):
        while len(out)%4:out.append(0)
        offset=len(out)
        out.extend(raw)
        view={'buffer':0,'byteOffset':offset,'byteLength':len(raw)}
        if target:view['target']=target
        lg['bufferViews'].append(view)
        return len(lg['bufferViews'])-1

    def append_accessor(raw,component,typ,count,target=None):
        view=append_block(raw,target)
        lg['accessors'].append({'bufferView':view,'componentType':component,'type':typ,'count':count})
        return len(lg['accessors'])-1

    la['JOINTS_0']=append_accessor(joints.tobytes(),5121,'VEC4',len(joints),34962)
    la['WEIGHTS_0']=append_accessor(weights.astype('<f4').tobytes(),5126,'VEC4',len(weights),34962)

    # Importa TODA hierarquia original e seu inverse-bind, sem renomear bones,
    # evitando perder os targets indices dos canais de animacao.
    lg['nodes']=copy.deepcopy(ng['nodes'])
    lg['scenes']=copy.deepcopy(ng['scenes'])
    lg['scene']=ng.get('scene',0)
    lg['nodes'][49]['mesh']=0
    lg['nodes'][49]['skin']=0
    src_idxs={ng['skins'][0]['inverseBindMatrices']}
    for anim in ng['animations']:
        for samp in anim['samplers']:
            src_idxs.add(samp['input']);src_idxs.add(samp['output'])
    # Necessario copiar cada accessor dos 8 clips e as matrizes de bind.
    mapped_views={}; mapped_accessors={}
    for idx in sorted(src_idxs):
        a=copy.deepcopy(ng['accessors'][idx]);old_v=a['bufferView']
        if old_v not in mapped_views:
            v=ng['bufferViews'][old_v];begin=v.get('byteOffset',0)
            raw=nb[begin:begin+v['byteLength']]
            nv=append_block(raw,v.get('target'))
            if 'byteStride' in v:lg['bufferViews'][nv]['byteStride']=v['byteStride']
            mapped_views[old_v]=nv
        a['bufferView']=mapped_views[old_v]
        lg['accessors'].append(a)
        mapped_accessors[idx]=len(lg['accessors'])-1
    skin=copy.deepcopy(ng['skins'][0]);skin['inverseBindMatrices']=mapped_accessors[skin['inverseBindMatrices']]
    lg['skins']=[skin]
    lg['animations']=copy.deepcopy(ng['animations'])
    for anim in lg['animations']:
        for s in anim['samplers']:
            s['input']=mapped_accessors[s['input']];s['output']=mapped_accessors[s['output']]

    lg.setdefault('asset',{})['generator']='Transferencia de rig/animacoes Furia da Noite -> Furia da Luz (Python)'
    lg['asset'].setdefault('extras',{})['rigTransfer']={
        'sourceRig':'Furia_da_Noite_8_Animacoes.glb',
        'targetMesh':'firoa da luz.glb',
        'sourceVertexCount':len(npos),'targetVertexCount':len(pos),
        'jointCount':49,'clipNames':[a['name'] for a in lg['animations']],
        'originalLightMeshAndUVsPreserved':True,
        'originalLightTexturesPreserved':True,
        'approximateWeightTransfer':True,
        'geometryAlignmentScale':scales.tolist(),
        'geometryAlignmentTranslation':offs.tolist(),
        'alignmentIsApproximate':True,
        'recommendedNextValidation':'Revisar visualmente deformacao de asas, boca, patas e cauda em engine.'
    }
    lg['buffers'][0]['byteLength']=len(out)
    js=json.dumps(lg,ensure_ascii=False,separators=(',',':')).encode('utf8')
    js+=b' '*(-len(js)%4)
    out.extend(b'\0'*(-len(out)%4))
    with open(OUTPUT,'wb') as f:
        f.write(struct.pack('<III',0x46546c67,2,12+8+len(js)+8+len(out)))
        f.write(struct.pack('<II',len(js),0x4e4f534a));f.write(js)
        f.write(struct.pack('<II',len(out),0x004e4942));f.write(out)

    report={
        'out':OUTPUT.name,
        'source_rig_vertices':len(npos),'source_rig_joints':len(ng['skins'][0]['joints']),
        'target_light_vertices':len(pos),
        'target_faces':int(lg['accessors'][lpr['indices']]['count']//3),
        'light_images_kept':len(lg['images']),
        'light_original_textures_kept':len(lg['textures']),
        'clips':[(a['name'],a.get('extras',{}).get('durationSeconds')) for a in lg['animations']],
        'approx_alignment_nearest_distance_quantiles_meters':dict(zip(['p10','p50','p90','p95','p99'],map(float,np.percentile(closest,[10,50,90,95,99])))),
        'skin_influence_count_max':4,
        'skin_weights_sum_max_error':float(np.max(np.abs(np.sum(weights,axis=1)-1))),
        'joint_indices_range':[int(joints.min()),int(joints.max())],
        'dominant_joint_weight_quantiles':dict(zip(['p10','p50','p90'],map(float,np.percentile(dominance,[10,50,90])))),
        'limitations':[
            'Nao ha correspondencia exata de vertices; rigging automaticamente inferido por proximidade de superficies.',
            'Alinhamento e os pesos sao aproximados; movimentos devem ser revisados visualmente em varias poses.',
            'Nao existe controle manual de dedos ou novos joints que nao estavam no rig do Furia da Noite.'
        ]
    }
    REPORT.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
