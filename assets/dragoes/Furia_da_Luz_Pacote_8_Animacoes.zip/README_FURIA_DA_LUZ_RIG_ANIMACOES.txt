FÚRIA DA LUZ — RIG 49 OSSOS + 8 ANIMAÇÕES (REVISÃO 1)
====================================================

RESULTADO
- Furia_da_Luz_8_Animacoes_Rig49.glb
- Conserva a malha, os triângulos, a organização de UV e TODAS as texturas
  originais do arquivo "firoa da luz.glb" enviado pelo usuário.
- 49 ossos transferidos do GLB Fúria da Noite animado.
- Nova atribuição de pesos a 84.624 vértices do dragão branco.
- Transforma escala/posição da geometria do dragão branco para alinhá-la ao
  esqueleto e tamanho do dragão preto: scale [2.5373,2.2597,2.6290],
  translation [-0.0094,0.8596,-0.1004]. A pose e o material branco são mantidos.
- A versão preta original NÃO é adicionada como segunda malha visível.

CLIP (NOME EXATO)     DURAÇÃO     REPRODUÇÃO
Idle                  3.20s       loop
Walk                  1.05s       loop
Fly                   1.24s       loop
Glide                 2.70s       loop
Attack                1.45s       ação única
Hurt                  0.90s       ação única
Takeoff                1.88s       ação única
Landing                1.72s       ação única

TESTES CONCLUÍDOS
- GLB 2.0 parseado com sucesso pelo trimesh (147.342 triângulos).
- Mesmas 3 texturas e mesmo material do GLB branco original, byte-a-byte.
- Acesso íntegro a jointIds, inverse-bind-matrices e 8 animações.
- Todos os nomes e canais de animação verificáveis e com tempos ordenados.
- Pesos com até 4 influências, soma ~1, índices de juntas válidos.
- Testes numéricos de deformação em 5 momentos de cada animação.
- Poses das quatro ações cíclicas comparadas numericamente ao Fúria da Noite.

LIMITAÇÕES IMPORTANTES
- A geometria branca NÃO é exatamente igual à preta: 84.624 vs 69.756
  vértices. Os pesos foram estimados por correspondência espacial, não
  transferidos vértice-a-vértice nem pintados manualmente em software 3D.
- Pequenos artefatos em juntas, asas ou na mandíbula podem permanecer;
  revís-los visualmente em situações reais de combate e decolagem.
- NÃO foi testado dentro do jogo do usuário; isso requer sua versão atual.
- O movimento no mundo e a física (voar, aterrissar, colisões) continuam
  responsabilidade do código do jogo (as animações movimentam a pose).

COMO TESTAR
1. Abra Visualizador_Furia_da_Luz_8_Animacoes.html em um navegador com internet.
2. No seletor de arquivo, escolha Furia_da_Luz_8_Animacoes_Rig49.glb.
3. Teste os oito clipes, velocidades, zoom, rotação e poses.
4. No jogo Three.js, carregue o GLB via GLTFLoader e use as oito animações
   nomeadas com THREE.AnimationMixer(gltf.scene).

ARQUIVOS ADICIONAIS
- transferir_rig_e_animacoes.py: script reproduzível de transferência.
- Furia_da_Luz_8_Animacoes_Rig49.json: relatório estrutural e parâmetros.
- Furia_da_Luz_Analise_Animacoes.json: estiramento geométrico por clip.
- _qa_poses_furia_da_luz.png: visualização comparativa geométrica preto/branco.

Nenhum dragão principal do jogo foi substituído nesta etapa.
