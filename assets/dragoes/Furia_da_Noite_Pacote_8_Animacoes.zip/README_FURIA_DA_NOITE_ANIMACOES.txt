FURIA DA NOITE — PACOTE DE 8 ANIMACOES (glTF 2.0 / GLB)
========================================================

ARQUIVO PRINCIPAL
  Furia_da_Noite_8_Animacoes.glb

O modelo Mesh_0 original e as tres texturas JPEG embutidas foram
preservados. O rig existente SmartRigArmature possui 49 ossos.
Acrescentadas oito faixas de animacao independentes de 30 fps:

  Nome         Duracao    Modo       Descricao
  Idle          3,20 s    loop       Respiracao, oscilacao de cabeca/cauda e asas
  Walk          1,05 s    loop       Passos alternados, movimentacao de patas
  Fly           1,24 s    loop       Batidas de asa, articulacao de ponta e pulso
  Glide         2,70 s    loop       Asas estendidas, microcorrecoes no ar
  Attack        1,45 s    unica      Recuo, avanco da cabeca e abertura da mandibula
  Hurt          0,90 s    unica      Impacto, cabeca e asas reagem, recuperacao
  Takeoff       1,88 s    unica      Agachamento, impulso, batida e decolagem
  Landing       1,72 s    unica      Asas abertas, descida, pouso e absorcao

COMO TESTAR NO VISUALIZADOR
  1. Abra visualizador_furia_da_noite.html no Chrome ou Edge.
  2. Aguarde a biblioteca Three.js carregar (requer acesso a internet).
  3. Clique em 'Arquivo do dragao' e selecione o GLB deste pacote.
  4. Selecione as animacoes e use os controles de velocidade/pausa.

COMO USAR COM THREE.JS NO JOGO
  const gltf = await new GLTFLoader().loadAsync('caminho/dragao.glb');
  const mixer = new THREE.AnimationMixer(gltf.scene);
  const action = mixer.clipAction(THREE.AnimationClip.findByName(gltf.animations, 'Fly'));
  action.play();
  // No loop de renderizacao: mixer.update(deltaEmSegundos);

As animacoes sao IN-PLACE em X/Z (o deslocamento horizontal e realizado pelo
sistema de voo/caminhada do jogo). Existe pequeno movimento vertical no root
para decolagem, pouso e estabilizacao. As poses de transicao foram planejadas
para Takeoff -> Fly e Glide -> Landing -> Idle.

TESTES EFETUADOS
  - Cabecalho GLB e chunks JSON/BIN validos
  - Oito animacoes encontradas com os nomes previstos
  - 49 ossos do rig original preservados
  - Geometria, pesos, materiais, texturas, UVs identicos ao arquivo de entrada
  - Todos os keyframes com tempos crescentes e sem NaN
  - Quaternions normalizados
  - Loops com primeiro e ultimo quadro coincidentes
  - Deformacao matematica de skinning verificada em 40 poses

LIMITACAO / IMPORTANTE
  Nenhum projeto do jogo foi alterado; o dragao principal NAO foi substituido.
  Nao foi testado em execucao no jogo. Verifique no visualizador e no motor do
  jogo as transicoes, colisoes no chao e a altura durante o voo.

Gerador reproduzivel:
  python gerar_animacoes_furia_da_noite.py entrada.glb saida.glb
  Dependencias Python: numpy, scipy
