#!/usr/bin/env python3
"""Insere 8 clips glTF 2.0 no Fúria da Noite sem alterar a geometria/UV/materiais.
Necessita: Python 3, numpy, scipy. Execucao: python gerar_animacoes_furia_da_noite.py entrada.glb saida.glb
Modelo: SmartRigArmature de 49 juntas / Mesh_0 original, eixo frente +Z.
"""
import copy
import json
import math
import struct
import sys
from pathlib import Path

import numpy as np
from scipy.spatial.transform import Rotation

INPUT = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/mnt/data/furia da noite.glb')
OUTPUT = Path(sys.argv[2]) if len(sys.argv) > 2 else Path('/mnt/data/Furia_da_Noite_8_Animacoes.glb')

with open(INPUT, 'rb') as f:
    mag, ver, size = struct.unpack('<III', f.read(12))
    if (mag, ver) != (0x46546C67, 2):
        raise ValueError('Arquivo nao e GLB 2.0')
    jslen, jstype = struct.unpack('<II', f.read(8))
    if jstype != 0x4E4F534A:
        raise ValueError('Chunk JSON invalido')
    gltf = json.loads(f.read(jslen))
    binlen, bintype = struct.unpack('<II', f.read(8))
    if bintype != 0x004E4942:
        raise ValueError('Chunk BIN invalido')
    source_bin = f.read(binlen)

if gltf.get('animations'):
    raise ValueError('O GLB ja possui animacoes. Use o GLB de origem sem clips para evitar duplicacoes.')
if len(gltf.get('skins', [])) != 1 or len(gltf['skins'][0]['joints']) != 49:
    raise ValueError('Esperava o rig de 49 ossos do arquivo Furia da Noite.')

nodes = gltf['nodes']
parent = {c: i for i, n in enumerate(nodes) for c in n.get('children', [])}


def local_rotation(i):
    return Rotation.from_quat(nodes[i].get('rotation', [0, 0, 0, 1]))


def local_matrix(i):
    nd = nodes[i]
    if 'matrix' in nd:
        return np.asarray(nd['matrix'], dtype=float).reshape((4, 4)).T
    mat = np.eye(4)
    mat[:3, :3] = local_rotation(i).as_matrix() @ np.diag(nd.get('scale', [1, 1, 1]))
    mat[:3, 3] = nd.get('translation', [0, 0, 0])
    return mat


world_cache = {}
def bind_world(i):
    if i not in world_cache:
        world_cache[i] = ((bind_world(parent[i]) if i in parent else np.eye(4)) @ local_matrix(i))
    return world_cache[i]


# Anatomia identificada por coordenadas da malha e pelos pesos de skinning:
# +Z cabeca, -Z cauda; -X asa esquerda / +X asa direita.
B = {
    'root': 48, 'spine': 47,
    'neck': 6, 'head': 5, 'muzzle': 4, 'lower_jaw': 1, 'upper_jaw': 3,
    'wing_l': [20, 19, 18, 17], 'wing_r': [24, 23, 22, 21],
    'fore_l': [11, 10, 9], 'fore_r': [16, 15, 14],
    'rear_l': [31, 30, 29], 'rear_r': [36, 35, 34],
    'tail': [46, 45, 44, 43, 42, 41, 40, 39, 38, 37],
}
J = sorted(set([48, 47, 6, 5, 4, 1, 3] + sum((B[k] for k in ['wing_l', 'wing_r', 'fore_l', 'fore_r', 'rear_l', 'rear_r', 'tail']), [])))
rest = {i: local_rotation(i) for i in J}
parent_rest = {i: Rotation.from_matrix(bind_world(parent[i])[:3, :3]) if i in parent else Rotation.identity() for i in J}

TAU = 2 * math.pi
S = math.sin
C = math.cos

def clamp(x):
    return max(0., min(1., x))

def smooth(x):
    v = clamp(x)
    return v * v * (3 - 2 * v)

def ramp(t, begin, end):
    return smooth((t - begin) / (end - begin))

def pulse(t, a, b, c, d):
    """Curva de ataque: entrada, platô, recuperação."""
    return ramp(t, a, b) * (1 - ramp(t, c, d))

class Pose:
    def __init__(self):
        self.angles = {}  # angulos desejados em eixos globais em RADIANOS (x,y,z)
        self.dy = 0.
        self.dx = 0.
        self.dz = 0.

    def add(self, i, x=0., y=0., z=0.):
        a = self.angles.setdefault(i, np.zeros(3, dtype=np.float64))
        a += np.array([x, y, z], dtype=np.float64)

    def blend(self, other, k):
        mixed = Pose()
        for bone in set(self.angles) | set(other.angles):
            mixed.angles[bone] = self.angles.get(bone, np.zeros(3))*(1-k) + other.angles.get(bone, np.zeros(3))*k
        mixed.dy = self.dy*(1-k) + other.dy*k
        mixed.dx = self.dx*(1-k) + other.dx*k
        mixed.dz = self.dz*(1-k) + other.dz*k
        return mixed


def wing(p, rise, spread=0., twist=0., elbow_ratio=.47, tip_ratio=.21):
    """Simetria: z faz o arco vertical, y faz a varredura para tras."""
    for key, side in [('wing_l', -1), ('wing_r', +1)]:
        sh, el, wr, tip = B[key]
        p.add(sh, z=side*rise, y=side*spread, x=twist)
        p.add(el, z=side*rise*elbow_ratio, y=side*spread*.31, x=twist*.6)
        p.add(wr, z=side*rise*tip_ratio, y=side*spread*.13, x=twist*.3)
        p.add(tip, z=side*rise*.07)


def tail(p, bend=0., wag=0., wave=0.):
    for k, i in enumerate(B['tail']):
        taper = .5 + .50*k/9
        p.add(i, y=taper*(wag*(.22+.075*k)+wave*S(.32*k)),
              x=taper*bend*(.46 + .055*k))


def legs(p, front=0., rear=0., tuck=0., spread=0.):
    for key, sign, swing in [('fore_l', +1, front), ('fore_r', -1, front), ('rear_l', -1, rear), ('rear_r', +1, rear)]:
        top, mid, foot = B[key]
        p.add(top, x=sign*swing + .26*tuck, z=sign*spread*.65)
        p.add(mid, x=-sign*swing*.52 - .43*tuck)
        p.add(foot, x=sign*swing*.16 + .12*tuck)


def idle(t):
    p = Pose(); w = TAU*t/3.2
    wing(p, -.19 + .018*S(w), spread=.12 + .014*S(w+.6), twist=.009*S(w))
    p.add(B['spine'], x=.018*S(w), y=.007*S(w*.5))
    p.add(B['neck'], x=-.012*S(w+.38))
    p.add(B['head'], x=.022*S(w+.8), y=.021*S(w*.6))
    p.add(B['muzzle'], x=.004*S(w+.8))
    tail(p, bend=.018*S(w-.1), wag=.022*S(w*.85), wave=.013*S(w+.1))
    p.dy = .008*(1-C(w))
    return p


def walk(t):
    p = Pose(); w = TAU*t/1.05
    # Passos diagonais: dianteira esquerda/traseira direita e par oposto.
    legs(p, front=.31*S(w), rear=.28*S(w+.4), spread=.015)
    for key, sign in [('fore_l',1), ('fore_r',-1), ('rear_l',-1), ('rear_r',1)]:
        p.add(B[key][1], x=.08*max(0,S(w*(1 if key.startswith('fore') else 1)+ (0 if sign==1 else math.pi))))
    wing(p, -.25 + .026*S(w+.35), spread=.16)
    p.add(B['spine'], x=.032*S(w+.4), z=.019*S(w))
    p.add(B['neck'], x=-.040*S(w+.1))
    p.add(B['head'], x=.035*S(w+.7))
    tail(p, bend=.03*S(w+.7), wag=.036*S(w+math.pi/2), wave=.015*S(w+.5))
    p.dy = .018*(1-C(2*w))
    return p


def fly(t):
    p = Pose(); w = TAU*t/1.24
    # Batida de asa completa com flexao de pulso atrasada e fluxo para tras.
    lift = .52*S(w)
    sweep = .12 + .20*max(0., -S(w))
    wing(p, lift, spread=sweep, twist=.052*S(w+.35), elbow_ratio=.46, tip_ratio=.22)
    for key, side in [('wing_l',-1), ('wing_r',1)]:
        shoulder, elbow, wrist, tip = B[key]
        p.add(elbow, z=side*.17*(S(w-.48)-S(w)))
        p.add(wrist, z=side*.13*(S(w-.75)-S(w)))
        p.add(tip, z=side*.070*(S(w-1)-S(w)))
    p.add(B['spine'], x=.038*S(w+.5), z=.018*S(w+.9))
    p.add(B['neck'], x=-.037*S(w+.15))
    p.add(B['head'], x=.024*S(w+.5))
    legs(p, tuck=.52 + .035*S(w), spread=.05)
    tail(p, bend=.05*S(w-.4), wag=.033*S(w+.85), wave=.023*S(w-.4))
    p.dy = .31 + .037*S(w-.4)
    return p


def glide(t):
    p = Pose(); w = TAU*t/2.7
    wing(p, .155 + .023*S(w), spread=.085 + .017*S(w+.9), twist=.012*S(w*.6), elbow_ratio=.23, tip_ratio=.06)
    p.add(B['spine'], x=-.022 + .010*S(w), z=.012*S(w+.7))
    p.add(B['neck'], x=.013*S(w+.4))
    p.add(B['head'], x=-.015+.012*S(w*.66+.9), y=.010*S(w+.3))
    legs(p, tuck=.48, spread=.035)
    tail(p, bend=.014+.021*S(w+.4), wag=.03*S(w), wave=.015*S(w+.5))
    p.dy = .31 + .012*S(w+.4)
    return p


def attack(t):
    p = idle(0)
    anticipation = pulse(t, .07, .22, .27, .38)
    strike = pulse(t, .32, .47, .68, .95)
    bite = pulse(t, .36, .46, .63, .89)
    recoil = pulse(t, .74, .88, 1.12, 1.40)
    p.add(B['spine'], x=-.10*anticipation+.15*strike-.06*recoil)
    p.add(B['neck'], x=-.16*anticipation + .21*strike)
    p.add(B['head'], x=-.19*anticipation + .35*strike - .10*recoil, y=.065*strike)
    p.add(B['muzzle'], x=.08*strike)
    p.add(B['lower_jaw'], x=.43*bite)
    p.add(B['upper_jaw'], x=-.070*bite)
    for key, side in [('wing_l',-1), ('wing_r',1)]:
        sh,el,wr,tip=B[key]
        p.add(sh, z=side*(.27*anticipation + .36*strike), y=side*(-.08*strike))
        p.add(el, z=side*.15*strike)
    tail(p, bend=.15*anticipation-.13*strike, wag=.09*strike)
    p.dy += -.055*anticipation+.040*strike-.028*recoil
    p.dz = .13*strike
    return p


def hurt(t):
    p = idle(0)
    shock = pulse(t, .02, .13, .29, .76)
    rebound = pulse(t, .26, .39, .53, .84)
    p.add(B['spine'], x=-.15*shock+.085*rebound, y=.055*shock, z=-.12*shock+.035*rebound)
    p.add(B['neck'], x=-.26*shock+.14*rebound)
    p.add(B['head'], x=-.25*shock+.10*rebound, y=.13*shock)
    for key, side in [('wing_l',-1), ('wing_r',1)]:
        sh,el,wr,tip=B[key]
        p.add(sh, z=side*(.17*shock+.10*rebound), y=side*(.09*shock))
        p.add(el, z=side*(.07*shock))
    legs(p, tuck=.28*shock)
    tail(p, bend=.09*shock-.03*rebound, wag=.15*shock-.07*rebound, wave=.025*shock)
    p.dy += -.076*shock+.024*rebound
    p.dz = -.08*shock
    return p


def takeoff(t):
    # Inicio exatamente alinhado ao Idle(0); final alinhado ao Fly(0).
    k = ramp(t, .46, 1.88)
    p = idle(0).blend(fly(0), k)
    crouch = pulse(t, .03, .19, .27, .43)
    push = pulse(t, .26, .47, .70, 1.04)
    p.add(B['spine'], x=.14*crouch-.15*push)
    p.add(B['neck'], x=.12*crouch-.10*push)
    p.add(B['head'], x=.08*crouch-.09*push)
    for key, side in [('wing_l',-1), ('wing_r',1)]:
        sh,el,wr,tip=B[key]
        p.add(sh, z=side*(-.34*crouch+.71*push), y=side*.09*push)
        p.add(el, z=side*(-.12*crouch + .30*push))
        p.add(wr, z=side*.16*push)
    legs(p, tuck=.17*crouch-.16*push)
    tail(p, bend=-.08*crouch+.12*push)
    p.dy += -.085*crouch+.12*push
    return p


def landing(t):
    # Inicio alinhado a Glide(0); final alinhado ao Idle(0).
    k = ramp(t, .25, 1.72)
    p = glide(0).blend(idle(0), k)
    spread = pulse(t, .12, .40, .61, 1.03)
    cushion = pulse(t, .74, .98, 1.12, 1.46)
    for key, side in [('wing_l',-1), ('wing_r',1)]:
        sh,el,wr,tip=B[key]
        p.add(sh, z=side*(.33*spread - .14*cushion))
        p.add(el, z=side*.18*spread)
        p.add(wr, z=side*.08*spread)
    p.add(B['spine'], x=.08*cushion-.05*spread)
    p.add(B['neck'], x=.06*cushion)
    p.add(B['head'], x=-.055*cushion)
    legs(p, tuck=-.38*spread+.19*cushion)
    tail(p, bend=.11*spread-.06*cushion)
    p.dy += -.035*cushion
    return p


clips = [
    ('Idle', 3.2, idle, True),
    ('Walk', 1.05, walk, True),
    ('Fly', 1.24, fly, True),
    ('Glide', 2.7, glide, True),
    ('Attack', 1.45, attack, False),
    ('Hurt', .9, hurt, False),
    ('Takeoff', 1.88, takeoff, False),
    ('Landing', 1.72, landing, False),
]

# Guarda buffers originais SEM alterar bytes da malha, da armadura ou das texturas.
output_bin = bytearray(source_bin)
while len(output_bin) % 4: output_bin.append(0)
new_views = []
new_accessors = []


def push_accessor(arr, type_name, minmax=False):
    arr = np.asarray(arr, dtype='<f4', order='C')
    while len(output_bin) % 4: output_bin.append(0)
    offset = len(output_bin)
    raw = arr.tobytes(order='C')
    output_bin.extend(raw)
    view_index = len(gltf['bufferViews']) + len(new_views)
    new_views.append({'buffer': 0, 'byteOffset': offset, 'byteLength': len(raw)})
    idx = len(gltf['accessors']) + len(new_accessors)
    a = {'bufferView': view_index, 'componentType': 5126, 'count': len(arr), 'type': type_name}
    if minmax:
        a['min'] = [float(arr.min())]
        a['max'] = [float(arr.max())]
    new_accessors.append(a)
    return idx


animations = []
for name, duration, fn, loop in clips:
    # Inclusao do frame final; lerp linear suave e q normalizadas.
    n_steps = int(math.ceil(duration * 30))
    times = np.linspace(0, duration, n_steps + 1, dtype=np.float64)
    poses = [fn(float(tt)) for tt in times]
    if loop:
        poses[-1] = poses[0]  # loop sem costura, incluindo variacao de altura
    joint_ids = sorted(set().union(*(p.angles.keys() for p in poses)))
    # Insere bone_000 para a raiz, e qualquer outro osso acionado.
    inputs_idx = push_accessor(times.astype('f4'), 'SCALAR', minmax=True)
    outputs = []
    channels = []
    samplers = []

    for ji in joint_ids:
        qq = []
        for pose in poses:
            world_angles = pose.angles.get(ji, np.zeros(3, dtype=np.float64))
            # Eixo global em repouso -> eixo do pai local -> quat de animacao.
            rot_delta = Rotation.from_rotvec(world_angles)
            local_delta = parent_rest[ji].inv()*rot_delta*parent_rest[ji]
            q = (local_delta*rest[ji]).as_quat()
            if qq and np.dot(q, qq[-1]) < 0: q = -q
            qq.append(q)
        result = np.asarray(qq, dtype=np.float32)
        result /= np.linalg.norm(result, axis=1)[:,None]
        output_idx = push_accessor(result, 'VEC4')
        si = len(samplers)
        samplers.append({'input':inputs_idx, 'output':output_idx, 'interpolation':'LINEAR'})
        channels.append({'sampler':si, 'target':{'node':ji,'path':'rotation'}})

    trans = np.array([np.array(nodes[48].get('translation',[0,0,0]))+
                 np.array([p.dx,p.dy,p.dz]) for p in poses], dtype=np.float32)
    output_idx = push_accessor(trans,'VEC3')
    si = len(samplers)
    samplers.append({'input':inputs_idx, 'output':output_idx, 'interpolation':'LINEAR'})
    channels.append({'sampler':si, 'target':{'node':48,'path':'translation'}})
    animations.append({'name':name, 'samplers':samplers, 'channels':channels,
                       'extras':{'loop':loop,'fps':30,'inPlace':True,
                                 'recommendedCrossfade':.15 if loop else .10,
                                 'durationSeconds':duration}})
    print(f'{name:<8} {duration:.2f}s {len(times)} quadros / {len(joint_ids)} ossos / {len(channels)} canais')

gltf['animations'] = animations
gltf['bufferViews'].extend(new_views)
gltf['accessors'].extend(new_accessors)
gltf['buffers'][0]['byteLength'] = len(output_bin)
gltf['asset'].setdefault('extras',{})['animationAuthoring'] = {
    'description':'8 animacoes skeletal no rig preexistente de 49 ossos',
    'axisForward':'+Z', 'axisUp':'+Y', 'sourceMeshUnchanged': True,
    'loops':['Idle','Walk','Fly','Glide'],
    'oneShots':['Attack','Hurt','Takeoff','Landing'],
    'locomotion':'In-place: a translacao horizontal do dragao e controlada pelo jogo.',
    'note':'Takeoff acaba na pose inicial de Fly; Landing comeca na pose inicial de Glide.'
}

json_bytes = json.dumps(gltf,ensure_ascii=False,separators=(',',':')).encode('utf8')
json_bytes += b' ' * (-len(json_bytes) % 4)
output_bin.extend(b'\0' * (-len(output_bin)%4))
length = 12+8+len(json_bytes)+8+len(output_bin)
with open(OUTPUT,'wb') as f:
    f.write(struct.pack('<III', 0x46546C67,2,length))
    f.write(struct.pack('<II', len(json_bytes), 0x4E4F534A))
    f.write(json_bytes)
    f.write(struct.pack('<II',len(output_bin),0x004E4942))
    f.write(output_bin)
print('Salvo',OUTPUT, 'bytes:', OUTPUT.stat().st_size)
