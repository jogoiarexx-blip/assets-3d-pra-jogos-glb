#!/usr/bin/env python3
"""Create a skinned skeletal GLB from an unrigged Meshy GLB.

Pure Python / NumPy, preserving original geometry, UVs, normals, texture images,
and material in the binary GLB. Add 22 bones, four skinning influences per vertex,
and three preview animation clips. Usage:
  python rig_chaves.py INPUT.glb OUTPUT.glb
"""
import json
import math
import struct
import sys
from pathlib import Path
import numpy as np


def glb_read(file_path):
    data = Path(file_path).read_bytes()
    magic, version, length = struct.unpack_from('<4sII', data, 0)
    if magic != b'glTF' or version != 2 or length != len(data):
        raise ValueError('Expected a standard binary GLB v2')
    off = 12
    chunks = []
    while off < len(data):
        size, tag = struct.unpack_from('<I4s', data, off)
        off += 8
        chunks.append((tag, data[off:off + size]))
        off += size
    info = json.loads(next(block for tag, block in chunks if tag == b'JSON'))
    binary = next((block for tag, block in chunks if tag == b'BIN\x00'), b'')
    return info, bytearray(binary)


def get_positions(doc, buffer):
    a = doc['accessors'][doc['meshes'][0]['primitives'][0]['attributes']['POSITION']]
    v = doc['bufferViews'][a['bufferView']]
    if v.get('byteStride', 12) != 12 or a['componentType'] != 5126:
        raise ValueError('Expected uncompressed FLOAT VEC3 positions')
    return np.frombuffer(buffer, dtype='<f4', count=a['count'] * 3,
                         offset=v.get('byteOffset', 0) + a.get('byteOffset', 0)).reshape(-1, 3).copy()


def smooth(a, b, x):
    t = np.clip((x - a) / (b - a), 0, 1)
    return t*t*(3 - 2*t)


def bones():
    # Global joint positions in original coordinate system.  +Y is up, +Z is forward.
    return [
        ('Root', None, (0.0, 0.0, 0.0)),
        ('Hips', 'Root', (0.0, -0.260, 0.0)),
        ('Spine', 'Hips', (0.0, -0.060, 0.0)),
        ('Chest', 'Spine', (0.0, 0.205, 0.0)),
        ('Neck', 'Chest', (0.0, 0.388, 0.0)),
        ('Head', 'Neck', (0.0, 0.472, 0.006)),
        ('Clavicle_L', 'Chest', (0.092, 0.271, 0.0)),
        ('UpperArm_L', 'Clavicle_L', (0.175, 0.248, 0.0)),
        ('Forearm_L', 'UpperArm_L', (0.230, -0.060, 0.0)),
        ('Hand_L', 'Forearm_L', (0.286, -0.229, 0.010)),
        ('Clavicle_R', 'Chest', (-0.092, 0.271, 0.0)),
        ('UpperArm_R', 'Clavicle_R', (-0.175, 0.248, 0.0)),
        ('Forearm_R', 'UpperArm_R', (-0.230, -0.060, 0.0)),
        ('Hand_R', 'Forearm_R', (-0.286, -0.229, 0.010)),
        ('Thigh_L', 'Hips', (0.114, -0.365, 0.0)),
        ('Shin_L', 'Thigh_L', (0.128, -0.625, -0.038)),
        ('Foot_L', 'Shin_L', (0.149, -0.832, -0.037)),
        ('Toe_L', 'Foot_L', (0.164, -0.910, 0.083)),
        ('Thigh_R', 'Hips', (-0.114, -0.365, 0.0)),
        ('Shin_R', 'Thigh_R', (-0.128, -0.625, -0.038)),
        ('Foot_R', 'Shin_R', (-0.149, -0.832, -0.037)),
        ('Toe_R', 'Foot_R', (-0.164, -0.910, 0.083)),
    ]


def calculate_weights(positions, joint_list):
    count = len(positions)
    x, y, z = positions.T
    w = np.zeros((count, len(joint_list)), dtype=np.float64)
    look = {name:i for i,(name,_,_) in enumerate(joint_list)}
    def put(name, val): w[:, look[name]] += val

    # Arm segmentation: outboard silhouette and sleeve/forearm contours.
    outer_threshold = np.interp(y, [-0.35,-0.26,-0.18,-0.10,0.0,0.12,0.25,0.35],
                                  [0.270,0.236,0.192,0.166,0.146,0.143,0.134,0.145])
    arm_mask = (smooth(outer_threshold - 0.022, outer_threshold + 0.013, np.abs(x))
                * smooth(-0.37,-0.235,y) * (1-smooth(0.30,0.40,y)))
    # Smooth separation of shorts/trousers from the pelvis, so leg turns do not drag torso.
    leg_mask = (1-smooth(-0.415,-0.287,y)) * (1-arm_mask)
    core_mask = np.maximum(0.0, 1-arm_mask-leg_mask)

    # Trunk: piecewise, linear anatomically sensible vertical bone distribution.
    trunk_stops = [(-1.0,'Hips'),(-0.215,'Hips'),(-0.065,'Spine'),
                   (0.145,'Chest'),(0.337,'Chest'),(0.405,'Neck'),
                   (0.492,'Head'),(1.20,'Head')]
    for (ya,ba),(yb,bb) in zip(trunk_stops[:-1],trunk_stops[1:]):
        mask = (y>=ya)&(y<yb)
        if not np.any(mask): continue
        t = smooth(ya,yb,y[mask])
        w[mask,look[ba]] += core_mask[mask]*(1-t)
        w[mask,look[bb]] += core_mask[mask]*t
    # Hat brim/ear flaps belong with head even below neck, avoid neck stretching hat.
    brim = (smooth(0.375,0.443,y)*(1-smooth(0.48,0.52,y))
            * smooth(0.115,0.175,np.abs(x)) * core_mask * 0.85)
    w[:,look['Head']] += brim

    # Arms left and right. Clavicle helps movement at sleeve-shoulder seam.
    l_mask = smooth(-0.035,0.035,x)
    for side, side_mask in [('L',l_mask),('R',1-l_mask)]:
        m = arm_mask * side_mask
        # Upper-arm pivot and sleeve attach to the clavicle.
        shoulder_t = smooth(0.15,0.31,y)
        upper = (1-smooth(-0.118,-0.005,y)) * (1-shoulder_t)
        lower = smooth(-0.118,-0.005,y) * (1-smooth(-0.263,-0.176,y))
        # Interpolate between forearm and hand at wrist.
        hand = 1-smooth(-0.265,-0.178,y)
        # Upper arm at high shoulder; clavicle is reserved for uppermost attachment.
        put('Clavicle_'+side, m*shoulder_t*0.42)
        put('UpperArm_'+side, m*((1-hand)*upper + shoulder_t*0.58))
        put('Forearm_'+side, m*((1-hand)*lower))
        put('Hand_'+side, m*hand)
        # Fill upper arm blend in the elbow zone and prevent loss in high limb.
        total_arm = (shoulder_t*0.42 + (1-hand)*upper + shoulder_t*0.58
                     + (1-hand)*lower + hand)
        # In particular 'upper' tapers at wrist; fill forearm part below elbow.
        deficit = np.maximum(0.0,1-total_arm)
        put('Forearm_'+side,m*deficit)

    # Legs: shorts/thighs, knees and shins, ankles and forward-projecting shoes.
    for side,side_mask in [('L',l_mask),('R',1-l_mask)]:
        m = leg_mask * side_mask
        knee = smooth(-0.675,-0.548,y)
        foot = 1-smooth(-0.875,-0.789,y)
        toe = (smooth(0.028,0.143,z)*smooth(-0.945,-0.878,y))*foot*0.75
        put('Thigh_'+side, m*knee)
        put('Shin_'+side, m*(1-knee)*(1-foot))
        put('Foot_'+side, m*((1-knee)*foot-toe))
        put('Toe_'+side, m*toe)
        # Knee formula above fades thigh by y, but at top shin/feet need 100%.
        # Transfer residual thigh at foot/ankle into the foot bone.
        carry = m*knee*foot
        w[:,look['Thigh_'+side]] -= carry
        w[:,look['Foot_'+side]] += carry

    sums = w.sum(axis=1)
    if np.any(sums<1e-6):
        raise ValueError(f'{int((sums<1e-6).sum())} vertices without bone influences')
    w /= sums[:,None]
    top_indices = np.argsort(-w,axis=1,kind='stable')[:,:4].astype('<u2')
    top_weights = np.take_along_axis(w,top_indices,axis=1)
    top_weights /= top_weights.sum(axis=1,keepdims=True)
    return top_indices, top_weights.astype('<f4')


def glb_append(doc, data, arr, component_type, typ, target=None):
    while len(data)%4:data.append(0)
    offset=len(data)
    byt=np.ascontiguousarray(arr).tobytes()
    data.extend(byt)
    view={'buffer':0,'byteOffset':offset,'byteLength':len(byt)}
    if target is not None:view['target']=target
    vindex=len(doc['bufferViews'])
    doc['bufferViews'].append(view)
    acc={'bufferView':vindex,'byteOffset':0,'componentType':component_type,
         'count':len(arr),'type':typ}
    aindex=len(doc['accessors'])
    doc['accessors'].append(acc)
    return aindex


def q_axis(axis, angle):
    a=np.asarray(axis,dtype=np.float64)
    a=a/np.linalg.norm(a)
    return (np.array([a[0]*np.sin(angle/2),a[1]*np.sin(angle/2),
                      a[2]*np.sin(angle/2),np.cos(angle/2)],dtype='<f4'))


def add_animation(doc, data, name_to_node, name, times, channels):
    anim={'name':name,'samplers':[],'channels':[]}
    timeidx=glb_append(doc,data,np.array(times,dtype='<f4').reshape(-1,1),5126,'SCALAR')
    doc['accessors'][timeidx]['min']=[float(min(times))]
    doc['accessors'][timeidx]['max']=[float(max(times))]
    for node_name,axis,angles in channels:
        quats=np.array([q_axis(axis,a) for a in angles],dtype='<f4')
        qi=glb_append(doc,data,quats,5126,'VEC4')
        si=len(anim['samplers'])
        anim['samplers'].append({'input':timeidx,'output':qi,'interpolation':'LINEAR'})
        anim['channels'].append({'sampler':si,'target':{'node':name_to_node[node_name],'path':'rotation'}})
    doc.setdefault('animations',[]).append(anim)


def make_animations(doc, data, names):
    idle_t=np.linspace(0,2.0,17)
    make_idle=lambda scale,phase=0: np.sin(idle_t*np.pi+phase)*scale
    add_animation(doc,data,names,'Idle_Respiracao',idle_t,[
        ('Chest',(1,0,0),make_idle(0.018)),
        ('Head',(0,0,1),make_idle(0.012)),
        ('UpperArm_L',(0,0,1),make_idle(0.011)),
        ('UpperArm_R',(0,0,1),make_idle(-0.011)),
    ])
    t=np.linspace(0,1.0,25)
    phase=t*2*np.pi
    add_animation(doc,data,names,'Andar_No_Lugar',t,[
        ('Thigh_L',(1,0,0),0.36*np.sin(phase)),
        ('Thigh_R',(1,0,0),-0.36*np.sin(phase)),
        ('Shin_L',(1,0,0),0.29*np.maximum(0,-np.sin(phase))),
        ('Shin_R',(1,0,0),0.29*np.maximum(0,np.sin(phase))),
        ('UpperArm_L',(1,0,0),-0.25*np.sin(phase)),
        ('UpperArm_R',(1,0,0),0.25*np.sin(phase)),
        ('Forearm_L',(1,0,0),-0.12*np.sin(phase)),
        ('Forearm_R',(1,0,0),0.12*np.sin(phase)),
        ('Chest',(0,0,1),0.02*np.sin(phase*2)),
    ])
    wave=np.linspace(0,2.0,33)
    smoothup=smooth(0,0.40,wave)*(1-smooth(1.50,1.95,wave))
    add_animation(doc,data,names,'Acenar_Mao_Esquerda',wave,[
        ('UpperArm_L',(0,0,1),smoothup*1.80),
        ('Forearm_L',(0,0,1),smoothup*0.35),
        ('Hand_L',(0,0,1),smoothup*0.20*np.sin(wave*14.0)),
    ])


def export_glb(doc, data, output):
    doc['buffers'][0]['byteLength']=len(data)
    json_blob=json.dumps(doc,ensure_ascii=False,separators=(',',':')).encode('utf-8')
    json_blob+=b' '*((-len(json_blob))%4)
    while len(data)%4:data.append(0)
    length=12+8+len(json_blob)+8+len(data)
    output=Path(output)
    with output.open('wb') as f:
        f.write(struct.pack('<4sII',b'glTF',2,length))
        f.write(struct.pack('<I4s',len(json_blob),b'JSON'))
        f.write(json_blob)
        f.write(struct.pack('<I4s',len(data),b'BIN\x00'))
        f.write(data)


def run(inp,out):
    doc,data=glb_read(inp)
    if len(doc['meshes'])!=1 or len(doc['meshes'][0]['primitives'])!=1:
        raise ValueError('This input-specific automatic skinning expects one mesh / one primitive.')
    if 'skins' in doc and doc['skins']:
        raise ValueError('This model already has a skin. Refusing to overwrite.')
    verts=get_positions(doc,data)
    bone_spec=bones()
    indices, weights=calculate_weights(verts,bone_spec)
    attr=doc['meshes'][0]['primitives'][0]['attributes']
    attr['JOINTS_0']=glb_append(doc,data,indices,5123,'VEC4',34962)
    attr['WEIGHTS_0']=glb_append(doc,data,weights,5126,'VEC4',34962)
    # Preserve original node and all 3 original JPEG textures and material fields.
    meshnode=next(i for i,n in enumerate(doc['nodes']) if n.get('mesh')==0)
    nodes=doc['nodes']
    names={}
    positions={name:np.asarray(xyz,dtype=float) for name,_,xyz in bone_spec}
    for name,parent,xyz in bone_spec:
        parentxyz=positions[parent] if parent else np.zeros(3)
        nd={'name':name,'translation':[float(i) for i in (positions[name]-parentxyz)]}
        names[name]=len(nodes)
        nodes.append(nd)
    for name,parent,_ in bone_spec:
        if parent is not None:
            nodes[names[parent]].setdefault('children',[]).append(names[name])
    # The skin skeleton root and the skinned mesh share the same original scene.
    doc['scenes'][doc.get('scene',0)]['nodes'].append(names['Root'])
    invbind=np.zeros((len(bone_spec),4,4),dtype='<f4')
    for i,(_,_,xyz) in enumerate(bone_spec):
        invbind[i]=np.eye(4,dtype='<f4')
        invbind[i,:3,3]=-np.asarray(xyz,dtype='<f4')
    # Each MAT4 is stored column-major in glTF.
    invacc=glb_append(doc,data,invbind.transpose(0,2,1),5126,'MAT4')
    doc.setdefault('skins',[]).append({'name':'Chaves_Rig_22_Ossos','inverseBindMatrices':invacc,
                                       'joints':[names[n] for n,_,_ in bone_spec],
                                       'skeleton':names['Root']})
    doc['nodes'][meshnode]['skin']=len(doc['skins'])-1
    doc['nodes'][meshnode]['name']='Chaves_Malha_Com_Rig'
    make_animations(doc,data,names)
    doc.setdefault('asset',{})['generator']='Chaves Rig Automático - glTF Skin + Anim Preview'
    export_glb(doc,data,out)
    print('Exportado:',out)
    print('Vertices:',len(verts),'Bones:',len(bone_spec),'Influencias:',indices.shape[1])
    print('Clipes: '+', '.join(a['name'] for a in doc['animations']))
    return doc,indices,weights

if __name__=='__main__':
    if len(sys.argv)!=3:
        print('Usage: python rig_chaves.py entrada.glb saida.glb')
        raise SystemExit(2)
    run(sys.argv[1],sys.argv[2])
