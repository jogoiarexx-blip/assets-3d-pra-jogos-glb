# Relatório técnico REV4 → REV5

Data: 22/10/2026

## Comparação

| Critério | REV4 | REV5 |
|---|---:|---:|
| Ossos de skin | 45 | 45 |
| Animações | 15 | **17** |
| Ações originais preservadas | 15 | **15/15** |
| Ataques refinados extras | 0 | **2** |
| Rig, malha, texturas e materiais | Meshy | **Idênticos à REV4** |
| Combate com retorno a movimento anterior | Limitado | **Sim, no controlador** |
| Eventos de acerto e magia | Não | **Sim, callbacks, sem hitbox física** |
| Correção IK para pés | Não | **Módulo CCD opcional, não validado em WebGL** |

## Deformação geométrica

Métrica: máximo P95/P99 da razão de comprimento de arestas deformadas em relação à malha de referência, amostrado em 20%, 52%, 80% de cada clip. **Menor não significa obrigatoriamente animação artística superior.** Comparação entre cada ação original e a variante correspondente.

| Movimento | P95 REV4 | P95 refinado REV5 | P99 REV4 | P99 refinado REV5 |
|---|---:|---:|---:|---:|
| Attack → SwordAttack_Refined | 1,527× | **1,495×** | 2,409× | **2,363×** |
| Triple_Combo_Attack → TripleCombo_Refined | 1,361× | **1,340×** | 1,929× | **1,851×** |

Penetração mínima global (nestes três instantes): Attack −0,104 m → refinado −0,003 m; Triple_Combo_Attack −0,030 m → refinado +0,002 m. As unidades presumem a escala atual do GLB. **São amostras, não prova de contato perfeito em todo o movimento.**

O deslocamento horizontal animado da raiz nos dois golpes novos foi reduzido a 12% da variação em torno da pose de repouso. As ações Meshy originais continuam disponíveis para jogos que preferem root motion.

## Correções estruturais

- Originais não substituídos: 15 clipes e BIN original preservados; novos dados são acrescentados ao GLB.
- Correções de rotações concentradas nos ombros e braços, preservando mãos e dedos para a pegada da espada.
- Ajuste de chão nas animações novas apenas, por amostragem da malha e interpolação da translação vertical do quadril.
- Dois ossos por perna para correção CCD em runtime, sem plugin pago.
- Estado de morte bloqueia novas animações, retorno pós-ataque respeita locomotion selecionado, eventos temporizados configuráveis.

## Testes executados

1. `tests/regression_rev5.py`: aprovado, 15 clipes e malha/rig/texturas originais idênticos.
2. `tools/validate_rev5.py`: estrutura, pesos, deformação CPU e prévias VTK aprovados para os 17 clipes.
3. `tests/vtk_import_rev5.py`: VTK importou e renderizou o arquivo com 17 clipes e cinco atores.
4. `tests/controller.test.mjs`: retornos de ação, eventos, velocidade, bloqueio após morte e erros simulados aprovados.
5. Sintaxe JavaScript do viewer, controlador e IK verificada com Node.

## Pendências

- Necessário testar visualmente o FootPlantIK em WebGL e ajustar o amortecimento conforme o terreno e a escala real do jogador.
- Distâncias extremas nos ataques caíram, mas não desapareceram: P99 do ataque refinado ainda é 2,363×.
- Animação de morte necessita acabamento; esta revisão não a alterou.
- A espada é um acessório simples e os eventos de magia/impacto não implementam combate completo.
- O visualizador depende de internet para carregar a biblioteca Three.js; para distribuição totalmente offline, é necessário hospedar os módulos.

## Referências técnicas abertas

- Three.js — AnimationAction: https://threejs.org/docs/pages/AnimationAction.html
- Three.js — CCDIKSolver: https://threejs.org/docs/pages/CCDIKSolver.html (referência conceitual; este pacote usa uma implementação leve separada)
- Three.js — Animation System: https://threejs.org/manual/pages/animation-system.html
