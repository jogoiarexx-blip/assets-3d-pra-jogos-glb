#!/usr/bin/env python3
"""Structural and CPU-skinning checks and offline pose previews for merged REV4. Does not claim actual WebGL gameplay test."""
import json,struct,sys,math,copy,os
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation as R, Slerp
ROOT=Path(__file__).resolve().parents[1]
FILE=ROOT/'sources/Striped_Wanderer_REV4_CRUZADA.glb'

def read(p):
 data=p.read_bytes();jlen,jtype=struct.unpack_from('<I4s',data,12)
 assert jtype==b'JSON'; d=json.loads(data[20:20+jlen]);blen,btype=struct.unpack_from('<I4s',data,20+jlen)
 assert btype==b'BIN\0';raw=bytearray(data[28+jlen:28+jlen+blen]);assert len(raw)==blen
 return d,raw

def acc(d,raw,i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']]
 t=np.dtype({5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']]);dim={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
 off=a.get('byteOffset',0)+v.get('byteOffset',0);stride=v.get('byteStride',t.itemsize*dim)
 return np.ndarray((a['count'],dim),dtype=t,buffer=raw,offset=off,strides=(stride,t.itemsize)).copy()

d,b=read(FILE)
assert len(d['skins'][0]['joints'])==45
assert len(d['animations'])==15
assert len(set(a['name'] for a in d['animations']))==15
assert len(d['meshes'])==3
for idx,a in enumerate(d['accessors']):
 if 'bufferView' in a:
  v=d['bufferViews'][a['bufferView']];assert v.get('byteOffset',0)+v['byteLength']<=len(b),(idx,'outside buffer')
for i,a in enumerate(d['animations']):
 seen=set()
 for ch in a['channels']:
  node=ch['target']['node'];path=ch['target']['path']
  assert node<len(d['nodes'])
  assert (node,path) not in seen,(a['name'],node,path,'duplicated target')
  seen.add((node,path))
  s=a['samplers'][ch['sampler']]
  times=acc(d,b,s['input']);data=acc(d,b,s['output'])
  assert len(times)==len(data) and len(times)>0,(a['name'],node,path)
  assert np.isfinite(times).all() and np.isfinite(data).all()
  assert np.all(np.diff(times[:,0])>0),(a['name'],node,path)
  if path=='rotation':
   assert np.max(abs(np.linalg.norm(data,axis=1)-1))<.002,(a['name'],node,'bad quaternion')
print('STRUCTURAL VALIDATION OK: 15 clips, 45 joints, all channels valid')

nodes=d['nodes'];parent={ch:i for i,n in enumerate(nodes) for ch in n.get('children',[])}
meshp=d['meshes'][0]['primitives'][0];V=acc(d,b,meshp['attributes']['POSITION']).astype(float)
J=acc(d,b,meshp['attributes']['JOINTS_0']).astype(int);W=acc(d,b,meshp['attributes']['WEIGHTS_0']).astype(float)
IB=acc(d,b,d['skins'][0]['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1)
F=acc(d,b,meshp['indices']).astype(int).ravel().reshape(-1,3)
assert (J>=0).all() and (J<45).all() and np.allclose(np.sum(W,axis=1),1,atol=.003)
rest_lengths=np.linalg.norm(V[F[:,[0,1,2]]]-V[F[:,[1,2,0]]],axis=2).reshape(-1)
mask=rest_lengths>.0005

def sample(clip,t):
 transforms={}
 for c in clip['channels']:
  s=clip['samplers'][c['sampler']];times=acc(d,b,s['input'])[:,0];values=acc(d,b,s['output'])
  if len(times)==1:val=values[0]
  else:
   i=min(max(np.searchsorted(times,t,side='right')-1,0),len(times)-2)
   a=float(np.clip((t-times[i])/(times[i+1]-times[i]),0,1))
   if c['target']['path']=='rotation':
    qs=R.from_quat(np.asarray(values[[i,i+1]],dtype=float))
    val=Slerp([0,1],qs)([a]).as_quat()[0]
   else:val=values[i]*(1-a)+values[i+1]*a
  transforms[(c['target']['node'],c['target']['path'])]=val
 cache={}
 def mat(i):
  if i not in cache:
   n=nodes[i]
   tran=transforms.get((i,'translation'),n.get('translation',[0,0,0]))
   rot=transforms.get((i,'rotation'),n.get('rotation',[0,0,0,1]))
   scale=transforms.get((i,'scale'),n.get('scale',[1,1,1]))
   m=np.eye(4);m[:3,:3]=R.from_quat(rot).as_matrix()*np.asarray(scale)[None,:];m[:3,3]=tran
   cache[i]=(mat(parent[i])@m if i in parent else m)
  return cache[i]
 joint_nodes=d['skins'][0]['joints']
 world=np.stack([mat(i) for i in joint_nodes])
 bones=np.matmul(world,IB)
 vh=np.column_stack([V,np.ones(len(V))])
 posed=np.einsum('nkij,nj,nk->ni',bones[J],vh,W)[:,:3]
 assert np.isfinite(posed).all()
 return posed,world,transforms

def main():
    rest_pose=[]
    for a in d['animations']:
     duration=max(float(acc(d,b,s['input'])[:,0].max()) for s in a['samplers'])
     pct=[.2,.52,.8]
     worst=0;worst_p95=0;mins=[];maxs=[]
     for k in pct:
      posed,*_=sample(a,duration*k)
      lenp=np.linalg.norm(posed[F[:,[0,1,2]]]-posed[F[:,[1,2,0]]],axis=2).reshape(-1)
      ratio=np.maximum(lenp[mask]/rest_lengths[mask],rest_lengths[mask]/np.maximum(lenp[mask],1e-8))
      worst=max(worst,float(np.percentile(ratio,99)));worst_p95=max(worst_p95,float(np.percentile(ratio,95)))
      mins.append(posed.min(0));maxs.append(posed.max(0))
     rest_pose.append((a['name'],round(duration,3),round(worst_p95,3),round(worst,3),round(float(np.min(mins,axis=0)[1]),3),round(float(np.max(maxs,axis=0)[1]),3)))
    print('POSE METRICS (max across 20%/52%/80% clip: P95, P99 edge length ratio)')
    for row in rest_pose:print(row)
    (ROOT/'tests'/'pose_metrics.json').write_text(json.dumps([dict(zip(('name','duration','P95','P99','minY','maxY'),r)) for r in rest_pose],indent=2))
    
    # Generate poses by baking skinned positions onto the exact ORIGINAL Meshy textured mesh.
    # Resulting temporary GLB does not need animations/rig, so VTK will render accurately.
    try:
     import vtk
     from PIL import Image,ImageDraw
    except ImportError:
     print('No VTK or PIL; skip previews');sys.exit(0)
    
    selection=[('Walking',.25),('Running',.28),('Attack',.45),('Triple_Combo_Attack',.35),
               ('Idle',.2),('CastMagic',.47),('Jump',.48),('BlockSword',.5),('Death',.8),('SwordAttack_REV3',.65)]
    pre=ROOT/'previews';pre.mkdir(parents=True,exist_ok=True)
    original,ograw=read(ROOT/'sources/Meshy_AI_The_Striped_Wanderer_All_Animations.glb')
    origview=original['bufferViews'][original['accessors'][0]['bufferView']]
    assert origview['byteLength']==V.astype('<f4').nbytes
    original.pop('skins',None);original.pop('animations',None)
    for n in original['nodes']:
     n.pop('skin',None)
    original['scenes'][0]['nodes']=[45] # mesh node only; no skeleton transforms
    
    def glb_baked(pose,name):
     binbytes=bytearray(ograw)
     st=origview['byteOffset'];binbytes[st:st+pose.astype('<f4').nbytes]=pose.astype('<f4').tobytes()
     original['accessors'][0]['min']=pose.min(0).tolist();original['accessors'][0]['max']=pose.max(0).tolist()
     j=json.dumps(original,separators=(',',':')).encode();j+=b' '*((-len(j))%4)
     result=pre/('_temp_'+name+'.glb')
     with result.open('wb') as f:
      f.write(struct.pack('<4sII',b'glTF',2,12+8+len(j)+8+len(binbytes)))
      f.write(struct.pack('<I4s',len(j),b'JSON'));f.write(j)
      f.write(struct.pack('<I4s',len(binbytes),b'BIN\0'));f.write(binbytes)
     return result
    
    imgs=[]
    for name,pct in selection:
     ani=next(a for a in d['animations'] if a['name']==name)
     duration=max(float(acc(d,b,s['input'])[:,0].max()) for s in ani['samplers'])
     pose,*_=sample(ani,duration*pct)
     tmp=glb_baked(pose,name)
     ren=vtk.vtkRenderer();ren.SetBackground(.07,.09,.13)
     win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetSize(440,530);win.AddRenderer(ren)
     imp=vtk.vtkGLTFImporter();imp.SetFileName(str(tmp));imp.SetRenderWindow(win)
     try:imp.Update()
     except Exception as e:print('PREVIEW FAILURE',name,e);continue
     cam=ren.GetActiveCamera();cam.SetFocalPoint(0,.85,0);cam.SetPosition(0,.85,4);cam.SetViewUp(0,1,0);cam.ParallelProjectionOn();cam.SetParallelScale(1.11)
     ren.ResetCameraClippingRange();win.Render()
     fil=vtk.vtkWindowToImageFilter();fil.SetInput(win);fil.Update()
     output=pre/(name+'.png');writer=vtk.vtkPNGWriter();writer.SetInputConnection(fil.GetOutputPort());writer.SetFileName(str(output));writer.Write()
     win.Finalize();tmp.unlink(missing_ok=True)
     imgs.append((name,output));print('Rendered',name)
    if imgs:
     cols=5;rows=math.ceil(len(imgs)/cols);cw,ch=440,580
     sheet=Image.new('RGB',(cols*cw,rows*ch),'#101b27');dr=ImageDraw.Draw(sheet)
     for i,(name,filename) in enumerate(imgs):
      x=i%cols*cw;y=i//cols*ch
      im=Image.open(filename).convert('RGB');sheet.paste(im,(x,y+50));dr.text((x+16,y+18),name,fill='#eff7fd')
     sheet.save(pre/'REV4_poses_comparadas.jpg',quality=89)
     print('SHEET',pre/'REV4_poses_comparadas.jpg')

if __name__=='__main__':
    main()
