#!/usr/bin/env python3
"""REV5 non-destructive animation pass: retain REV4; add optimized in-place Meshy attacks.
The original 15 clips/meshes/skeleton/textures are preserved bytewise.
"""
from pathlib import Path
import struct, json, copy, math, sys, importlib.util, contextlib, io
import numpy as np
from scipy.spatial.transform import Rotation as R
OUT=Path(__file__).resolve().parents[1]
BASE=OUT
(OUT/'assets').mkdir(parents=True,exist_ok=True)
(OUT/'tests').mkdir(parents=True,exist_ok=True)
(OUT/'src').mkdir(parents=True,exist_ok=True)
original=BASE/'sources/Striped_Wanderer_REV4_CRUZADA.glb'
rawfile=original.read_bytes();l=struct.unpack_from('<I',rawfile,12)[0]
d=json.loads(rawfile[20:20+l]);binary=bytearray(rawfile[28+l:]);assert len(d['animations'])==15

def acc(i):
 a=d['accessors'][i];v=d['bufferViews'][a['bufferView']]
 k={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']]
 t=np.dtype({5120:'i1',5121:'u1',5122:'<i2',5123:'<u2',5125:'<u4',5126:'<f4'}[a['componentType']])
 off=v.get('byteOffset',0)+a.get('byteOffset',0)
 return np.ndarray((a['count'],k),dtype=t,buffer=binary,offset=off,strides=(v.get('byteStride',k*t.itemsize),t.itemsize)).copy()

def store(array,type_,component=5126):
 a=np.ascontiguousarray(array,dtype='<f4' if component==5126 else '<u2')
 while len(binary)%4:binary.append(0)
 offset=len(binary);binary.extend(a.tobytes());vi=len(d['bufferViews'])
 d['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':a.nbytes})
 ai=len(d['accessors']);o={'bufferView':vi,'componentType':component,'count':len(a),'type':type_}
 if type_=='SCALAR':o.update(min=[float(a.min())],max=[float(a.max())])
 d['accessors'].append(o)
 return ai

bone={node.get('name'):i for i,node in enumerate(d['nodes'])}
hip=bone['mixamorig:Hips']
report=[]
for source,newname in [('Attack','SwordAttack_Refined'),('Triple_Combo_Attack','TripleCombo_Refined')]:
 src=next(c for c in d['animations'] if c['name']==source)
 clone=copy.deepcopy(src);clone['name']=newname
 clone['extras']={'origin':source,'changes':['reduced upper-body rotation stress','reduced in-place XZ root travel','sampled ground-clearance correction'], 'originalMotionPreservedAs':source}
 hip_index=None
 for ch in clone['channels']:
  target=ch['target'];idx=target['node'];path=target['path'];name=d['nodes'][idx].get('name','')
  sampler=clone['samplers'][ch['sampler']]
  if path=='rotation':
   factor=1.0
   if 'Shoulder' in name:factor=.74
   elif name.endswith(('LeftArm','RightArm')):factor=.82
   elif 'ForeArm' in name:factor=.90
   elif name.endswith(('Spine1','Spine2')):factor=.96
   if factor<1:
    value=acc(sampler['output']).astype(float)
    rest=R.from_quat(d['nodes'][idx].get('rotation',[0,0,0,1]))
    delta=(rest.inv()*R.from_quat(value)).as_rotvec()*factor
    newq=(rest*R.from_rotvec(delta)).as_quat().astype('f4')
    # Ensure neighboring keyframes are quaternion-sign coherent.
    for i in range(1,len(newq)):
     if np.dot(newq[i-1],newq[i])<0:newq[i]*=-1
    sampler['output']=store(newq,'VEC4')
  elif path=='translation' and idx==hip:
   hip_index=ch['sampler']
   arr=acc(sampler['output']).astype(float)
   rest=np.array(d['nodes'][hip].get('translation',[0,0,0]),dtype=float)
   arr[:,[0,2]]=rest[[0,2]]+(arr[:,[0,2]]-rest[[0,2]])*.12
   sampler['output']=store(arr.astype('f4'),'VEC3')
 assert hip_index is not None
 d['animations'].append(clone)
 report.append({'name':newname,'source':source,'rootMotionXZFactor':.12,'shoulderFactor':.74,'upperArmFactor':.82})

# Reuse the validated CPU skinning evaluator for clip-sampled Y ground correction.
with contextlib.redirect_stdout(io.StringIO()):
 spec=importlib.util.spec_from_file_location('rev4test',str(BASE/'tools/rev4_pose_engine.py'))
 mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
mod.d=d;mod.b=binary;mod.nodes=d['nodes']
feet_rest=(mod.V[:,1]<.27)
assert feet_rest.sum()>500
for rec in report:
 clip=next(c for c in d['animations'] if c['name']==rec['name'])
 ch=next(c for c in clip['channels'] if c['target']=={'node':hip,'path':'translation'})
 sm=clip['samplers'][ch['sampler']];ts=acc(sm['input']).flatten()
 # Sample at key times by 2 to avoid doing hundreds of full mesh poses.
 sample_times=np.unique(np.r_[np.linspace(0,ts[-1],19),ts[[0,len(ts)//4,len(ts)//2,3*len(ts)//4,-1]]])
 shifts=[]
 for t in sample_times:
  posed,_,_=mod.sample(clip,float(t))
  bottom=min(float(posed[feet_rest,1].min()),float(posed[:,1].min()))
  shifts.append(float(np.clip(.004-bottom,0,.16)))
 offsets=np.interp(ts,sample_times,shifts)
 tr=acc(sm['output']);tr[:,1]+=offsets
 sm['output']=store(tr,'VEC3')
 rec['sampledLiftMax']=round(float(max(shifts)),4)
 rec['sampledLiftFrames']=len(sample_times)

# Preserve original bin bytes and indexes while appending new tracks/metadata.
d['asset']['generator']='Striped Wanderer REV5 - non-destructive combat refinement'
d['asset'].setdefault('extras',{})['rev5']='15 original animations + 2 independently selectable refined Meshy attacks'
d.setdefault('extras',{})['rev5RefinedClips']=report
while len(binary)%4:binary.append(0)
d['buffers'][0]['byteLength']=len(binary)
j=json.dumps(d,ensure_ascii=False,separators=(',',':')).encode('utf-8');j+=b' '*((-len(j))%4)
output=OUT/'assets/Striped_Wanderer_REV5.glb'
with output.open('wb') as f:
 f.write(struct.pack('<4sII',b'glTF',2,12+8+len(j)+8+len(binary)))
 f.write(struct.pack('<I4s',len(j),b'JSON'));f.write(j)
 f.write(struct.pack('<I4s',len(binary),b'BIN\0'));f.write(binary)
(OUT/'tests'/'build_report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('REV5:',output,output.stat().st_size,'clips',len(d['animations']))
print(json.dumps(report,indent=2))
