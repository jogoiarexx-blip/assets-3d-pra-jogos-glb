# Striped Wanderer REV5 — Combate refinado e correção de pés opcional

## Conteúdo

- `assets/Striped_Wanderer_REV5.glb`: GLB principal (45 ossos, 17 clips, dois acessórios já integrados).
- `index.html`: visualizador Three.js (CDN gratuito, requer internet apenas para a biblioteca).
- `src/WandererAnimator.js`: controlador de transições, filas de retorno à locomoção, velocidade e eventos de golpes/magia.
- `src/FootPlantIK.js`: CCD simples com duas articulações para *pequenas* correções de pés em piso plano; desligável no visualizador.
- `previews/REV5_poses_comparadas.jpg`: renderizações de amostras de animação (VTK).
- `sources/`: GLB original da REV4 e GLB Meshy usado em verificações/renderização.
- `tools/build_rev5.py` e `tools/rev4_pose_engine.py`: geração reproduzível.
- `tools/validate_rev5.py` e `tests/`: validação geométrica, regressão de conteúdo e controlador JS.

## Testar o visualizador

1. Extraia o ZIP.
2. Em um terminal, dentro da pasta `Striped_Wanderer_REV5_COMBATE_IK`, execute `python -m http.server 8000`.
3. Abra `http://localhost:8000`. Não abra o HTML via `file://`.
4. Compare `Attack` e `Triple_Combo_Attack` (originais) com `SwordAttack_Refined` e `TripleCombo_Refined`.
5. Use a caixa de seleção IK para ligar/desligar a correção de pés.

Importante: as dependências `three@0.180.0` ainda são servidas por CDN; funcionamento offline integral requer hospedar a biblioteca localmente.

## Integração em projetos Three.js

```js
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {WandererAnimator} from './src/WandererAnimator.js';
new GLTFLoader().load('./assets/Striped_Wanderer_REV5.glb', (gltf) => {
  scene.add(gltf.scene);
  const actor = new WandererAnimator(THREE, gltf,
    (clip, duration) => console.log('clip', clip, duration),
    (event) => {
      if (event.type === 'sword-hit') { /* conectar hitboxes reais do jogo */ }
      if (event.type === 'magic-release') { /* instanciar projétil real */ }
    },
    { enableFootIK: true, ik: {groundY: 0, strength: 0.55} }
  );
  actor.play('Idle');
  // Dentro de seu loop de renderização: actor.update(deltaSeconds);
  // Ao caminhar: actor.locomotion('Walking');
  // Ao atacar: actor.attack(); actor.attack(true); actor.cast();
});
```

Os eventos de golpe **não causam dano** por conta própria: o jogo precisa implementar colisão/hitbox. O módulo IK é uma aproximação leve para chão plano, não um sistema completo para escadas ou terreno irregular.

## O que mudou em relação à REV4

- 15 animações anteriores preservadas byte a byte no BIN original.
- `SwordAttack_Refined` e `TripleCombo_Refined` adicionadas: atenuação controlada das rotações de ombro/braço, deslocamento horizontal da raiz reduzido a 12% e elevação corretiva em amostras contra penetração do piso.
- Transições com crossfade e retorno à locomoção escolhida após golpes.
- Eventos temporizados de impacto de espada e disparo de magia.
- Correção de pés (IK via CCD opcional), mantendo o GLB sem dependência adicional.
- O visualizador emite pequenos efeitos visuais temporários para os eventos de espada e magia.

## Limitações e testes

Validado por testes de estrutura, CPU skinning em três tempos de cada clip, renderização das poses, importação e renderização do GLB pelo VTK, e testes simulados das regras do controlador JS.

**Não validado ainda:** execução completa do viewer em GPU WebGL/Three.js neste ambiente, resultado visual do IK em movimento real, teste de jogabilidade, colisões efetivas ou sincronia de dano no jogo. A animação `Death` da REV4 foi preservada, sem novo acabamento artístico. Revisão manual do rig ainda seria necessária para qualidade profissional.
