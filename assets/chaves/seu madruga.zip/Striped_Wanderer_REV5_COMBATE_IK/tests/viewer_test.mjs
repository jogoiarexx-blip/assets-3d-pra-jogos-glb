
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { WandererAnimator } from './src/WandererAnimator.js';
const canvas=document.querySelector('#canvas');
const holder=document.querySelector('#viewer');
const status=document.querySelector('#status');const overlay=document.querySelector('#overlay');
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true});
renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,2));
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;
renderer.toneMapping=THREE.ACESFilmicToneMapping;
renderer.outputColorSpace=THREE.SRGBColorSpace;
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(37,1,.03,100);camera.position.set(2.3,1.65,3.6);
const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(0,.91,0);controls.enableDamping=true;controls.maxPolarAngle=Math.PI*.53;controls.minDistance=1.6;controls.maxDistance=7;controls.update();
scene.add(new THREE.HemisphereLight(0xf7faff,0x40515f,2.2));
const key=new THREE.DirectionalLight(0xffffff,3.6);key.position.set(3,6,5);key.castShadow=true;key.shadow.mapSize.set(1024,1024);key.shadow.camera.left=-4;key.shadow.camera.right=4;key.shadow.camera.top=5;key.shadow.camera.bottom=-4;scene.add(key);
const fill=new THREE.DirectionalLight(0x93dfff,1.4);fill.position.set(-3,3,-2);scene.add(fill);
const floor=new THREE.Mesh(new THREE.CircleGeometry(2,72),new THREE.MeshStandardMaterial({color:0x21384b,roughness:1}));floor.rotation.x=-Math.PI/2;floor.position.y=-.015;floor.receiveShadow=true;scene.add(floor);
const grid=new THREE.GridHelper(4.4,18,0x497c8b,0x264251);grid.position.y=-.013;scene.add(grid);
let animator=null;
const oneShots=new Set(['Attack','Triple_Combo_Attack','SwordAttack_Refined','TripleCombo_Refined','SwordAttack_REV3','SwordCombo_REV3','CastMagic','Jump','HitReact','Death','BlockSword','Celebrate']);
const namesPt={SwordAttack_Refined:'Espada refinada',TripleCombo_Refined:'Combo refinado',Running:'Correr (Meshy)',Walking:'Andar (Meshy)',Attack:'Ataque (Meshy)',Triple_Combo_Attack:'Combo triplo (Meshy)',Idle:'Parado',Walk_REV3:'Andar (REV3)',Run_REV3:'Correr (REV3)',SwordAttack_REV3:'Espada (REV3)',SwordCombo_REV3:'Combo espada (REV3)',CastMagic:'Lançar magia',Jump:'Pular',HitReact:'Receber dano',Death:'Morrer',BlockSword:'Defender',Celebrate:'Comemorar'};
const buttons=document.querySelector('#buttons');
const shortcuts={Digit1:'Idle',Digit2:'Walking',Digit3:'Running',Digit4:'SwordAttack_Refined',Digit5:'TripleCombo_Refined',Digit6:'CastMagic',Space:'Jump'};
window.addEventListener('keydown',event=>{if(!animator||!shortcuts[event.code])return;event.preventDefault();animator.play(shortcuts[event.code]);});
new GLTFLoader().load('./assets/Striped_Wanderer_REV5.glb',glb=>{
 scene.add(glb.scene);
 glb.scene.traverse(obj=>{if(obj.isMesh){obj.castShadow=true;obj.receiveShadow=true;}});
 animator=new WandererAnimator(THREE,glb,(name,duration)=>{
  overlay.textContent=`${namesPt[name]??name} • ${duration.toFixed(2)} s`;
  document.querySelectorAll('#buttons button').forEach(button=>button.classList.toggle('active',button.dataset.clip===name));
 },event=>{
  document.querySelector('#events').textContent='Evento: '+event.type+' • '+event.clip;
  spawnFx(event.type);
 }, {enableFootIK:document.querySelector('#ikSwitch').checked});
 for(const clip of glb.animations){
  const button=document.createElement('button');button.textContent=namesPt[clip.name]||clip.name;button.dataset.clip=clip.name;
  button.title=`${clip.name} — ${clip.duration.toFixed(2)} s ${oneShots.has(clip.name)?'• ação única':'• loop'}`;
  button.addEventListener('click',()=>animator.play(clip.name));buttons.appendChild(button);
 }
 animator.play('Idle',0);
 status.textContent=`Carregado: ${glb.animations.length} animações, 45 ossos e dois acessórios. Clique para testar.`;
},progress=>{if(progress.total){status.textContent=`Carregando: ${Math.round(progress.loaded/progress.total*100)}%`;}}
,error=>{console.error(error);status.textContent=`Erro: ${error.message}. Use um servidor HTTP local, não file://.`;overlay.textContent='Falha ao carregar GLB';});
document.querySelector('#ikSwitch').addEventListener('change',e=>{if(animator){animator.ik.enabled=e.target.checked;animator.ik.reset();}});
const slider=document.querySelector('#speed');slider.addEventListener('input',()=>{const v=Number(slider.value);document.querySelector('#speedLabel').textContent=v.toFixed(2)+'×';animator?.setSpeed(v);});
// Visual sparks on gameplay event callbacks; attached weapons remain in the GLB.
const effects=[];
function spawnFx(type){
 if(!animator||!['sword-hit','magic-release'].includes(type))return;
 let source=null;animator.root.traverse(obj=>{if(obj.name===(type==='magic-release'?'REV4_Magic_LeftHand':'REV4_Sword_RightHand'))source=obj;});
 const center=new THREE.Vector3();if(source){source.getWorldPosition(center);}else center.set(0,1.2,.4);
 const sphere=new THREE.Mesh(new THREE.SphereGeometry(type==='magic-release'?.065:.038,9,7),new THREE.MeshBasicMaterial({color:type==='magic-release'?0x54eeff:0xffc65a,transparent:true,opacity:.85,depthWrite:false}));
 sphere.position.copy(center);scene.add(sphere);effects.push({mesh:sphere,life:.5,max:.5,type});
}
const clock=new THREE.Clock();
function resize(){const w=holder.clientWidth,h=holder.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();}
new ResizeObserver(resize).observe(holder);resize();
function animate(){requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.065);animator?.update(dt);for(let i=effects.length-1;i>=0;i--){const e=effects[i];e.life-=dt;e.mesh.material.opacity=Math.max(0,e.life/e.max);e.mesh.scale.setScalar(1+(1-e.life/e.max)*4);e.mesh.position.y+=dt*.23;if(e.life<=0){scene.remove(e.mesh);e.mesh.geometry.dispose();e.mesh.material.dispose();effects.splice(i,1);}}controls.update();renderer.render(scene,camera);}
animate();
