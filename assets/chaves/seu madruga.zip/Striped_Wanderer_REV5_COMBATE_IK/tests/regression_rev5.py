import json,struct,hashlib
from pathlib import Path
root=Path(__file__).resolve().parents[1]
def read(p):
 b=p.read_bytes();jl=struct.unpack_from('<I',b,12)[0];d=json.loads(b[20:20+jl]);bl=struct.unpack_from('<I',b,20+jl)[0];return d,b[28+jl:28+jl+bl]
a,rawa=read(root/'sources/Striped_Wanderer_REV4_CRUZADA.glb');b,rawb=read(root/'assets/Striped_Wanderer_REV5.glb')
assert len(b['skins'][0]['joints'])==len(a['skins'][0]['joints'])==45
assert len(a['animations'])==15 and len(b['animations'])==17
assert len(b['meshes'])==len(a['meshes']) and b['meshes']==a['meshes']
assert b['skins']==a['skins']
assert b['materials']==a['materials'] and b['images']==a['images'] and b['textures']==a['textures']
assert b['nodes']==a['nodes'], 'bone bind transforms and accessories must remain original'
assert b['animations'][:15]==a['animations'], 'source motion clips should be bitwise preserved'
assert rawb.startswith(rawa), 'original binary bytes should survive appended tracks exactly'
for i in range(15,17):
 clip=b['animations'][i]
 seen=set()
 for ch in clip['channels']:
  s=clip['samplers'][ch['sampler']]
  path=ch['target']['path']
  k=(ch['target']['node'],path)
  assert k not in seen,(clip['name'],k)
  seen.add(k)
  assert s['output']<len(b['accessors'])
 assert b['accessors'][s['output']]['count']>0
# names and source-binary fingerprint
assert len(set(c['name'] for c in b['animations']))==17
print('PASS: 15/15 source animations are structurally unchanged')
print('PASS: skeleton 45 bones, meshes, materials, textures and bind nodes unchanged')
print('PASS: original GLB BIN starts the new binary without alterations')
print('PASS: 2 additional clips, no channel collisions')
print('ORIGINAL BIN SHA256',hashlib.sha256(rawa).hexdigest())
print('NEW CLIPS',', '.join(a['name'] for a in b['animations'][15:]))
