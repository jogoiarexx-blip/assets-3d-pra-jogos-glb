import {strict as assert} from 'node:assert';
import {WandererAnimator} from '../src/WandererAnimator.js';
class FakeAction {
 constructor(mixer,clip){this.mixer=mixer;this.clip=clip;this.time=0;this.enabled=false;this.running=false;this.timeScale=1;this.weight=1;this.loop='repeat';}
 reset(){this.time=0;return this;}
 setLoop(mode){this.loop=mode;return this;}
 setEffectiveWeight(w){this.weight=w;return this;}
 setEffectiveTimeScale(s){this.timeScale=s;return this;}
 stopFading(){return this;}
 play(){this.running=true;return this;}
 stop(){this.running=false;return this;}
 crossFadeFrom(old){old.stop();return this;}
 isRunning(){return this.running;}
}
class FakeMixer {
 constructor(root){this.actions=[];this.listeners=[];this.timeScale=1;}
 clipAction(clip){const a=new FakeAction(this,clip);this.actions.push(a);return a;}
 addEventListener(e,cb){this.listeners.push([e,cb]);}
 update(dt){for(const action of this.actions){if(!action.running)continue;action.time+=dt*action.timeScale*this.timeScale;
 if(action.time>=action.clip.duration){if(action.loop==='once'){
  action.time=action.clip.duration;action.running=false;for(const [ev,cb] of this.listeners)if(ev==='finished')cb({action});
 }else{action.time%=action.clip.duration;}}
 }}
 stopAllAction(){for(const a of this.actions)a.stop();}
 uncacheRoot(){}
}
const THREE={AnimationMixer:FakeMixer,LoopOnce:'once',LoopRepeat:'repeat',Vector3:class{},Quaternion:class{}};
const names=['Idle','Walking','Running','Attack','Triple_Combo_Attack','SwordAttack_Refined','TripleCombo_Refined','CastMagic','Death'];
const scene={traverse(fn){fn(this);}};
const recorded=[];const events=[];
const a=new WandererAnimator(THREE,{scene,animations:names.map(name=>({name,duration:name==='CastMagic'?1.54:1}))},(n)=>recorded.push(n),ev=>events.push(ev));
assert.equal(a.ik.chains.length,0);
assert.equal(a.play('Idle',0),true);
assert.equal(a.activeName,'Idle');
a.locomotion('Running');assert.equal(a.activeName,'Running');
assert.equal(a.attack(),true);assert.equal(a.activeName,'SwordAttack_Refined');
a.locomotion('Walking');assert.equal(a.activeName,'SwordAttack_Refined');
a.update(.1);a.update(.1);a.update(.1);a.update(.1);
assert.equal(events.filter(x=>x.type==='sword-hit').length,1);
for(let k=0;k<8;k++)a.update(.1);
assert.equal(a.activeName,'Walking','must return to requested locomotion after attack');
a.cast();for(let k=0;k<9;k++)a.update(.1);
assert.equal(events.filter(x=>x.type==='magic-release').length,1);
a.play('Death');for(let k=0;k<12;k++)a.update(.1);
assert.equal(a.activeName,'Death');assert.equal(a.play('Running'),false);
a.setSpeed(1.25);assert.equal(a.mixer.timeScale,1.25);
assert.throws(()=>a.setSpeed(0));
assert.throws(()=>a.update(-1));
assert.throws(()=>a.play('Missing'));
a.dispose();
console.log('OK: return to locomotion, attack/magic events, death state, speed, error handling');
