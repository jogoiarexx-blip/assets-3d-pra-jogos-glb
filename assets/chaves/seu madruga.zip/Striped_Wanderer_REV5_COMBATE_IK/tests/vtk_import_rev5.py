from pathlib import Path
import vtk
p=Path(__file__).resolve().parents[1]/'assets/Striped_Wanderer_REV5.glb'
r=vtk.vtkRenderer();w=vtk.vtkRenderWindow();w.SetOffScreenRendering(1);w.SetSize(420,520);w.AddRenderer(r)
i=vtk.vtkGLTFImporter();i.SetFileName(str(p));i.SetRenderWindow(w);i.Update()
ac=i.GetNumberOfAnimations()
assert ac==17, f'VTK read {ac} animations'
w.Render()
print('PASS: VTK imported GLB and rendered scene; animations:',ac)
print('PASS: actor count',r.GetActors().GetNumberOfItems())
w.Finalize()
