// Local development server without external npm dependencies.
const http=require('node:http'),fs=require('node:fs'),path=require('node:path');
const root=__dirname;const port=Number(process.env.PORT||8765);
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.glb':'model/gltf-binary','.png':'image/png','.json':'application/json','.css':'text/css; charset=utf-8','.txt':'text/plain; charset=utf-8'};
http.createServer((req,res)=>{
 try{
  const url=new URL(req.url,'http://localhost');const relative=decodeURIComponent(url.pathname).replace(/^\/+/, '')||'index.html';
  const pathname=path.resolve(root,relative);
  if(pathname!==root&&!pathname.startsWith(root+path.sep)){res.writeHead(403);res.end('Negado');return}
  fs.stat(pathname,(e,s)=>{
   if(e||!s.isFile()){res.writeHead(404);res.end('Não encontrado');return}
   const stream=fs.createReadStream(pathname);
   res.writeHead(200,{'Content-Type':MIME[path.extname(pathname)]||'application/octet-stream','Content-Length':s.size,'Cache-Control':'no-store'});
   stream.on('error',()=>res.destroy());stream.pipe(res);
  });
 }catch(e){res.writeHead(400);res.end('Requisição inválida')}
}).listen(port,'127.0.0.1',()=>console.log(`Visualizador Zumbi REV3 em http://127.0.0.1:${port} - Ctrl+C encerra.`));
