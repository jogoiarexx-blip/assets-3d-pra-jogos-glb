/**
 * Controller with animation state, clip marker dispatch, sphere melee hits, and real target HP changes.
 * Import this module from a Three.js ESM project with the provided importmap.
 */
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { EVENTOS, LOOPS, crossedEvents, checkContact } from './Combate_REV3.mjs';

const ONE_SHOT=new Set(['Morder','Agarrar','Atacar','Dano','Tropecar','Morrer','Levantar']);
const CLIP_PRIORITY={Morrer:100,Dano:70,Tropecar:65,Levantar:95,Morder:45,Agarrar:45,Atacar:45};

export class ZumbiController {
  constructor(scene,gltf,{onEvent=()=>{},onHit=()=>{},onState=()=>{}}={}){
    this.object=gltf.scene;
    this.scene=scene;
    scene.add(this.object);
    this.object.traverse(o=>{if(o.isSkinnedMesh){o.castShadow=true;o.receiveShadow=true;o.frustumCulled=false;}});
    this.mixer=new THREE.AnimationMixer(this.object);
    this.clips=new Map(gltf.animations.map(clip=>[clip.name,clip]));
    this.bones=new Map();
    this.object.traverse(o=>{if(o.isBone||['Head','Jaw','R_Hand','L_Hand'].includes(o.name))this.bones.set(o.name,o);});
    this.onEvent=onEvent;this.onHit=onHit;this.onState=onState;
    this.target=null;this.current=null;this.currentName='';this.prevTime=0;
    this.locomotion='Parado';this.dead=false;this.locked=false;this.paused=false;
    this.grabbed=null;
    this.biteSensor=new THREE.Vector3();this.grabSensor=new THREE.Vector3();this.attackSensor=new THREE.Vector3();
    this._work=new THREE.Vector3();this._work2=new THREE.Vector3();
    this._facing=new THREE.Vector3();
    this.mixer.addEventListener('finished',e=>{
      if(e.action!==this.current)return;
      const finished=this.currentName;
      this.locked=false;this.grabbed=null;
      if(finished==='Morrer'){this.locked=true;return;}
      if(finished==='Levantar'){this.dead=false;this.locomotion='Parado';}
      this.play(this.locomotion,{force:true,fade:.22});
    });
    this.play('Parado',{force:true,fade:0});
  }
  hasClip(name){return this.clips.has(name);}
  setTarget(target){this.target=target;}
  setLocomotion(name){
    if(!LOOPS.has(name)||!this.clips.has(name)||this.dead)return false;
    this.locomotion=name;
    if(!this.locked&&!this.dead)this.play(name);
    return true;
  }
  play(name,{force=false,fade=.20}={}){
    if(!this.hasClip(name))return false;
    if(this.dead&&name!=='Levantar'&&name!=='Morrer'&&!force)return false;
    if(name==='Levantar'&&!this.dead&&!force)return false;
    const priority=CLIP_PRIORITY[name]||0;
    const previousPriority=CLIP_PRIORITY[this.currentName]||0;
    if(this.locked&&!force&&priority<previousPriority&&!(name==='Levantar'&&this.dead))return false;
    if(this.currentName===name&&this.current?.isRunning()&&!force)return true;
    if(LOOPS.has(name))this.locomotion=name;
    if(name==='Morrer')this.dead=true;
    if(name==='Levantar'){this.dead=true;this.grabbed=null;}
    if(!LOOPS.has(name))this.grabbed=null;
    const next=this.mixer.clipAction(this.clips.get(name));
    const previous=this.current;
    next.reset();next.enabled=true;next.paused=false;
    next.setEffectiveTimeScale(1);next.setEffectiveWeight(1);
    next.setLoop(LOOPS.has(name)?THREE.LoopRepeat:THREE.LoopOnce,LOOPS.has(name)?Infinity:1);
    next.clampWhenFinished=!LOOPS.has(name);next.play();
    if(previous&&previous!==next){
      previous.fadeOut(fade);
      if(fade>0)next.fadeIn(fade);
    }
    this.current=next;this.currentName=name;this.prevTime=-.0001;this.locked=ONE_SHOT.has(name);
    this.onState({name,dead:this.dead,loop:LOOPS.has(name)});
    return true;
  }
  // Provide the *model-relative* target Object3D positioned at root y=0, with visible parts around its local origin.
  _hitVolume(kind){
    const target=this.target;
    if(!target?.object||target.health<=0)return null;
    this.object.updateMatrixWorld(true);
    target.object.updateMatrixWorld(true);
    this.object.getWorldPosition(this._work);
    this.object.getWorldQuaternion(_tempQuat);
    this._facing.set(0,0,1).applyQuaternion(_tempQuat).normalize();
    const origin=new THREE.Vector3();
    let y=0,radius=.33;
    if(kind==='bite_hit'){
      this.bones.get('Jaw')?.getWorldPosition(origin);
      if(!this.bones.has('Jaw'))origin.copy(this._work).add(new THREE.Vector3(0,.7,.2));
      y=.67;radius=target.headRadius??.24;
      this.biteSensor.copy(origin);
    }else if(kind==='grab_attempt'){
      const left=this.bones.get('L_Hand'),right=this.bones.get('R_Hand');
      if(left&&right){left.getWorldPosition(origin);right.getWorldPosition(this._work2);origin.add(this._work2).multiplyScalar(.5);}
      else origin.copy(this._work).add(new THREE.Vector3(0,0,.35));
      y=-.03;radius=target.bodyRadius??.36;this.grabSensor.copy(origin);
    }else{
      this.bones.get('R_Hand')?.getWorldPosition(origin);
      if(!this.bones.has('R_Hand'))origin.copy(this._work).add(new THREE.Vector3(.3,0,.35));
      y=-.08;radius=target.bodyRadius??.36;this.attackSensor.copy(origin);
    }
    const hitPoint=new THREE.Vector3(0,y,0);
    target.object.localToWorld(hitPoint);
    return {origin,target:hitPoint,center:this._work,forward:this._facing,targetRadius:radius};
  }
  _dispatch(marker){
    const details={clip:this.currentName,time:marker.time,type:marker.type,hit:false,damage:0};
    if(['bite_hit','grab_attempt','attack_hit'].includes(marker.type)){
      const volume=this._hitVolume(marker.type);
      if(volume){
        const result=checkContact({...volume,maxDistance:marker.maxDistance,coneDeg:marker.coneDeg,radius:marker.radius});
        details.reason=result.reason;details.distance=result.distance;
        if(result.hit){
          details.hit=true;details.damage=marker.damage;
          this.target.health=Math.max(0,this.target.health-marker.damage);
          if(marker.type==='grab_attempt')this.grabbed=this.target;
          this.target.takeDamage?.(marker.damage,marker.type);
          this.onHit({...details,health:this.target.health,target:this.target});
        }
      }else details.reason='no_target';
    }else if(marker.type==='pull_target'&&this.grabbed&&this.grabbed.health>0){
      details.hit=true;details.damage=marker.damage;
      this.grabbed.health=Math.max(0,this.grabbed.health-marker.damage);
      this.grabbed.takeDamage?.(marker.damage,marker.type);
      // This demo only pulls a movable dummy. Integrations can replace with custom physics.
      if(this.grabbed.pullable){
        const targetPos=this.grabbed.object.position;
        const toward=this.object.position.clone().sub(targetPos);toward.y=0;
        if(toward.lengthSq()>1e-7)targetPos.addScaledVector(toward.normalize(),.18);
      }
      this.onHit({...details,health:this.grabbed.health,target:this.grabbed});
    }
    this.onEvent(details);
  }
  update(dt){
    if(this.paused||!this.current)return;
    const d=Math.min(.075,Math.max(0,dt));
    const before=this.prevTime;
    this.mixer.update(d);
    // animation finish callbacks can replace the active clip inside mixer.update.
    if(!this.current)return;
    const now=this.current.time;
    const duration=this.current.getClip().duration;
    const markers=EVENTOS[this.currentName]||[];
    for(const marker of crossedEvents(markers,before,now,duration,LOOPS.has(this.currentName)))this._dispatch(marker);
    this.prevTime=now;
  }
  setSpeed(multiplier){this.mixer.timeScale=Math.max(.1,Math.min(3,multiplier));}
  reset(){
    this.mixer.stopAllAction();this.dead=false;this.locked=false;this.grabbed=null;
    this.locomotion='Parado';this.current=null;this.currentName='';
    this.play('Parado',{force:true,fade:0});
  }
  remove(){this.mixer.stopAllAction();this.scene.remove(this.object);}
}
const _tempQuat=new THREE.Quaternion();
export async function carregarZumbi(scene,url='./Zumbi_Animado_REV3.glb',options={}){
  const gltf=await new GLTFLoader().loadAsync(url);
  return new ZumbiController(scene,gltf,options);
}
