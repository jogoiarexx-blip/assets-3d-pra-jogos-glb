#!/usr/bin/env python3
"""Rebuilds a GLB 2.0 with three extra baked bone animations, preserving REV2 mesh/textures."""
from pathlib import Path
import json,struct,math
import numpy as np
from scipy.spatial.transform import Rotation as R
BASE=Path(__file__).parent
SRC=BASE/'Zumbi_Animado_REV2.glb'
DST=BASE/'Zumbi_Animado_REV3.glb'
TYPE_DIMS={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
KINDS={5126:np.float32,5125:np.uint32,5123:np.uint16}
with SRC.open('rb') as f:
  magic,version,total=struct.unpack('<III',f.read(12))
  assert magic==0x46546c67 and version==2
  length,kind=struct.unpack('<II',f.read(8));assert kind==0x4e4f534a
  gltf=json.loads(f.read(length))
  length,kind=struct.unpack('<II',f.read(8));assert kind==0x004e4942
  raw=f.read(length)
blob=bytearray(raw)
assert len(blob)==gltf['buffers'][0]['byteLength']

def read_ac(idx):
 a=gltf['accessors'][idx];bv=gltf['bufferViews'][a['bufferView']]
 assert bv.get('byteStride') is None
 offset=bv.get('byteOffset',0)+a.get('byteOffset',0)
 num=a['count']*TYPE_DIMS[a['type']]
 return np.frombuffer(raw, dtype=KINDS[a['componentType']],count=num,offset=offset).reshape(a['count'],-1).copy()

def append_access(arr,format):
 arr=np.ascontiguousarray(arr,dtype=np.float32)
 while len(blob)%4:blob.append(0)
 offset=len(blob);blob.extend(arr.tobytes())
 index_view=len(gltf['bufferViews']);gltf['bufferViews'].append({'buffer':0,'byteOffset':offset,'byteLength':arr.nbytes})
 idx=len(gltf['accessors']);a={'bufferView':index_view,'componentType':5126,'count':arr.shape[0],'type':format}
 if format=='SCALAR':a['min']=[float(arr.min())];a['max']=[float(arr.max())]
 gltf['accessors'].append(a)
 return idx

def get_clip(name):
 a=next(a for a in gltf['animations'] if a['name']==name)
 result={}
 for ch in a['channels']:
  sp=a['samplers'][ch['sampler']]
  result[(ch['target']['node'],ch['target']['path'])]=(read_ac(sp['input'])[:,0],read_ac(sp['output']))
 return result

CLIPS={name:get_clip(name) for name in ('Parado','Dano','Morrer')}
PIVOT={i:n.get('name','') for i,n in enumerate(gltf['nodes'])}
INDEX={name:idx for idx,name in PIVOT.items()}

def sample(clip,k,time):
 times,values=CLIPS[clip][k]
 t=np.clip(time,times[0],times[-1]);hi=np.searchsorted(times,t,'right')
 if hi>=len(times):return values[-1].copy()
 if hi==0:return values[0].copy()
 lo=hi-1
 f=float((t-times[lo])/(times[hi]-times[lo]))
 if k[1]=='rotation':
  q1=values[lo];q2=values[hi]
  if np.dot(q1,q2)<0:q2=-q2
  dot=np.clip(np.dot(q1,q2),-1,1)
  if dot>0.9995:
   v=q1*(1-f)+q2*f
   return v/np.linalg.norm(v)
  theta=math.acos(dot)
  return (math.sin((1-f)*theta)*q1+math.sin(f*theta)*q2)/math.sin(theta)
 return values[lo]*(1-f)+values[hi]*f

def smoother(t,a,b):
 x=np.clip((t-a)/(b-a),0,1)
 return float(x*x*(3-2*x))

def bell(t,a,b,c,d):
 return smoother(t,a,b)*(1-smoother(t,c,d))

def perturb(base,name,time,duration):
 k=(INDEX[name],'rotation')
 pose=sample(base,k,time)
 return pose

def animate(name,duration,fps,pose_fun,events):
 frame_times=np.linspace(0,duration,int(round(duration*fps))+1,dtype=np.float32)
 animation={'name':name,'samplers':[],'channels':[],
   'extras':{'loop':name=='Procurar','contactEvents':events,'rev':'REV3'}}
 inp=append_access(frame_times.reshape(-1,1),'SCALAR')
 for j in gltf['skins'][0]['joints']:
  node=PIVOT[j]
  for path in ('rotation',)+(('translation',) if node in ('Hips','Jaw') else ()):
   out=[]
   for t in frame_times:
    tf=float(t);n=j
    q=pose_fun(tf,duration,node,path)
    if path=='rotation':
     q=np.asarray(q,dtype=np.float64);q=q/np.linalg.norm(q)
    out.append(q)
   data=np.asarray(out,dtype=np.float32)
   ind=append_access(data,'VEC4' if path=='rotation' else 'VEC3')
   sampler=len(animation['samplers'])
   animation['samplers'].append({'input':inp,'output':ind,'interpolation':'LINEAR'})
   animation['channels'].append({'sampler':sampler,'target':{'node':j,'path':path}})
 gltf['animations'].append(animation)
 print(name,len(frame_times),'frames',len(animation['channels']),'tracks')

# Quaternion rotations composed in node-local axes to retain existing rig mechanics.
def compose(q,axis,rad):
 return (R.from_quat(q)*R.from_euler(axis,rad)).as_quat()

def procurar(t,d,node,path):
 v=sample('Parado',(INDEX[node],path),t/d*2.8)
 if path=='rotation':
  wave=math.sin(t/d*2*math.pi)
  focus=math.sin(2*math.pi*(t/d)-.5)
  mods={'Head':('y',.27*wave),'Neck':('y',.18*wave),
        'Chest':('y',.075*focus),'Spine':('y',.04*focus),
        'R_Shoulder':('x',.085*math.sin(t*1.7)),
        'L_Shoulder':('x',-.065*math.sin(t*1.4))}
  if node in mods:
   axis,vv=mods[node];v=compose(v,axis,vv)
 return v

def tropecar(t,d,node,path):
 pulse=bell(t,.1,.42,.85,1.51)
 peak=bell(t,.24,.52,.78,1.2)
 recover=bell(t,.88,1.2,1.35,1.7)
 v=sample('Dano',(INDEX[node],path),t/d*.87)
 if path=='rotation':
  if node in ('Spine','Chest'):v=compose(v,'x',(.18 if node=='Spine' else .26)*pulse)
  elif node=='Hips':v=compose(v,'z',-.20*pulse+.08*recover)
  elif node=='Neck':v=compose(v,'x',-.10*pulse)
  elif node=='R_Shoulder':v=compose(v,'x',-.55*peak)
  elif node=='L_Shoulder':v=compose(v,'x',-.34*peak)
  elif node=='R_Knee':v=compose(v,'x',-.32*peak)
  elif node=='L_Knee':v=compose(v,'x',.22*peak)
  elif node=='R_Ankle':v=compose(v,'x',.18*peak)
  elif node=='L_Ankle':v=compose(v,'x',-.11*peak)
 elif node=='Hips':
  v[1]-=.095*peak;v[2]+=.075*pulse;v[0]-=.04*pulse
 return v

def levantar(t,d,node,path):
 # Reverse from final death pose into a standing pose; pause at start and settle at end.
 progress=smoother(t,.16,2.20)
 death_length=2.05
 time=death_length*(1-progress)
 v=sample('Morrer',(INDEX[node],path),time)
 brace=bell(t,.18,.5,1.0,1.46)
 if path=='rotation':
  if node=='R_Shoulder':v=compose(v,'x',-.20*brace)
  elif node=='L_Shoulder':v=compose(v,'x',-.19*brace)
  elif node=='R_Elbow':v=compose(v,'x',-.25*brace)
  elif node=='L_Elbow':v=compose(v,'x',-.25*brace)
 return v

animate('Procurar',3.2,30,procurar,[])
animate('Tropecar',1.7,40,tropecar,[])
animate('Levantar',2.5,40,levantar,[])
# In-GLB markers are redundant with the shipped JSON and can be accessed from gltf.animations[n].userData in Three.js
for a in gltf['animations']:
 a.setdefault('extras',{})
 a['extras']['rev']='REV3'
 if a['name'] in ['Parado','Andar','Correr','Procurar']:a['extras']['loop']=True
 else:a['extras']['loop']=False
metadata={
  'Morder':[{'time':.56,'type':'bite_hit','damage':22,'radius':.43,'maxDistance':1.1,'coneDeg':95}],
  'Agarrar':[{'time':.85,'type':'grab_attempt','damage':6,'radius':.61,'maxDistance':1.2,'coneDeg':105}, {'time':1.18,'type':'pull_target','damage':4}],
  'Atacar':[{'time':.44,'type':'attack_hit','damage':14,'radius':.61,'maxDistance':1.25,'coneDeg':110}],
  'Andar':[{'time':.16,'type':'footstep','foot':'left'},{'time':.94,'type':'footstep','foot':'right'}],
  'Correr':[{'time':.1,'type':'footstep','foot':'left'},{'time':.53,'type':'footstep','foot':'right'}],
  'Morrer':[{'time':1.02,'type':'body_impact'}],
  'Levantar':[{'time':2.20,'type':'standing_up'}]
}
for a in gltf['animations']:
 a['extras']['contactEvents']=metadata.get(a['name'],[])
gltf['asset']['generator']='Zumbi Meshy REV3 - extending REV2 authored tracks, 11 animations'
gltf['extras']={'revision':'REV3','source':'REV2','changes':'Three new baked clips Procurar, Tropecar, Levantar, contact event metadata in animation.extras, mesh and textures untouched'}
gltf['buffers'][0]['byteLength']=len(blob)
jbuf=json.dumps(gltf,separators=(',',':'),ensure_ascii=False).encode()
jbuf+=b' ' * (-len(jbuf)%4)
blob.extend(b'\x00'*(-len(blob)%4))
size=12+8+len(jbuf)+8+len(blob)
with DST.open('wb') as f:
 f.write(struct.pack('<III',0x46546c67,2,size))
 f.write(struct.pack('<II',len(jbuf),0x4e4f534a));f.write(jbuf)
 f.write(struct.pack('<II',len(blob),0x004e4942));f.write(blob)
print('CREATED',DST,DST.stat().st_size, 'animation count:',len(gltf['animations']))
