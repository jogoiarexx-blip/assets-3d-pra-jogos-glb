#!/usr/bin/env python3
"""Structural validation of REV3 plus verification that REV2 mesh, skins and images remain identical."""
from pathlib import Path
from collections import Counter
import struct,json,hashlib,numpy as np
D=Path(__file__).parent
EXPECTED=['Parado','Andar','Correr','Morder','Agarrar','Atacar','Dano','Morrer','Procurar','Tropecar','Levantar']

def open_glb(p):
 with p.open('rb') as f:
  magic,version,tot=struct.unpack('<III',f.read(12))
  assert magic==0x46546c67 and version==2 and tot==p.stat().st_size
  l,k=struct.unpack('<II',f.read(8)); assert k==0x4e4f534a;J=json.loads(f.read(l))
  l,k=struct.unpack('<II',f.read(8)); assert k==0x004e4942;B=f.read(l)
  assert len(B)==l==J['buffers'][0]['byteLength']
 return J,B
old,ob=open_glb(D/'Zumbi_Animado_REV2.glb')
new,nb=open_glb(D/'Zumbi_Animado_REV3.glb')
assert len(new['skins'])==1 and len(new['skins'][0]['joints'])==22
assert [a['name'] for a in new['animations']]==EXPECTED
assert len(new['meshes'])==len(old['meshes'])==1
assert new['meshes']==old['meshes']
assert new['nodes']==old['nodes']
assert new['skins']==old['skins']
assert new['images']==old['images']
assert new['materials']==old['materials']
assert len(new['textures'])==len(old['textures'])
assert nb[:len(ob)]==ob
assert new['accessors'][:len(old['accessors'])]==old['accessors']
assert new['bufferViews'][:len(old['bufferViews'])]==old['bufferViews']

def access(i):
 a=new['accessors'][i];bv=new['bufferViews'][a['bufferView']]
 typ={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}[a['type']];dtype={5126:np.float32,5125:np.uint32,5123:np.uint16}[a['componentType']]
 assert bv.get('byteStride') is None
 arr=np.frombuffer(nb,dtype=dtype,count=a['count']*typ,offset=bv.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,typ)
 assert len(arr)==a['count']
 assert a['count']>0
 return arr
for clip in new['animations']:
 channels=clip['channels'];assert len(channels)==24
 cnt=Counter((c['target']['node'],c['target']['path']) for c in channels)
 assert all(x==1 for x in cnt.values())
 durations=[]
 for c in channels:
  s=clip['samplers'][c['sampler']];assert s['interpolation']=='LINEAR'
  times=access(s['input'])[:,0];out=access(s['output'])
  assert len(times)==len(out) and np.all(np.isfinite(times)) and np.all(np.diff(times)>0)
  assert np.all(np.isfinite(out)) and times[0]==0
  if c['target']['path']=='rotation':
   norms=np.linalg.norm(out,axis=1)
   assert np.all(np.abs(norms-1)<1e-4)
  durations.append(float(times[-1]))
 assert max(durations)-min(durations)<1e-3
 print(f"PASS {clip['name']}: {len(channels)} canais, {len(access(clip['samplers'][0]['input']))} quadros, {durations[0]:.2f}s, eventos {len(clip.get('extras',{}).get('contactEvents',[]))}")
weights=access(new['meshes'][0]['primitives'][0]['attributes']['WEIGHTS_0'])
assert abs(float(np.mean(weights.sum(axis=1)))-1)<1e-4
assert np.min(weights)>=0
assert len(weights)==60255
print('PASS geometria, 60.255 vertices, pesos 22 bones, 3 texturas e buffers mesh 100% identicos a REV2')
print('PASS 11 animacoes, GLB 2.0, dados validos')
