import test from 'node:test';
import assert from 'node:assert/strict';
import {EVENTOS,LOOPS,crossedEvents,checkContact} from './Combate_REV3.mjs';

test('mordida dispara uma só vez na janela de contato',()=>{
 const a=EVENTOS.Morder;
 assert.equal(crossedEvents(a,.45,.60,1.28,false).length,1);
 assert.equal(crossedEvents(a,.60,.75,1.28,false).length,0);
});
test('andada conta passagem da virada de ciclo',()=>{
 const arr=crossedEvents(EVENTOS.Andar,1.4,.2,1.55,true);
 assert.equal(arr.length,1);assert.equal(arr[0].foot,'L');
 assert.deepEqual(crossedEvents(EVENTOS.Andar,1.4,.2,1.55,false),[]);
});
test('mordida atinge alvo dentro do alcance e cone',()=>{
 const m=EVENTOS.Morder[0];
 const result=checkContact({
  origin:{x:-.018,y:.17,z:.723},target:{x:.07,y:.67,z:.7},
  center:{x:0,y:0,z:0},forward:{x:0,y:0,z:1},
  radius:m.radius,targetRadius:.24,maxDistance:m.maxDistance,coneDeg:m.coneDeg
 });
 assert.equal(result.hit,true);
});
test('agarrar acerta perto com sensor nas mãos',()=>{
 const m=EVENTOS.Agarrar[0];
 assert.equal(checkContact({
  origin:{x:-.0055,y:-.084,z:.915},target:{x:.07,y:-.03,z:.7},
  center:{x:0,y:0,z:0},forward:{x:0,y:0,z:1},
  radius:m.radius,targetRadius:.36,maxDistance:m.maxDistance,coneDeg:m.coneDeg
 }).hit,true);
});
test('rejeita alvo atrás do zumbi',()=>{
 const m=EVENTOS.Morder[0];
 const d=checkContact({origin:{x:0,y:.65,z:.22},target:{x:0,y:.65,z:-.3},center:{x:0,y:0,z:0},forward:{x:0,y:0,z:1},radius:m.radius,targetRadius:.24,maxDistance:m.maxDistance,coneDeg:m.coneDeg});
 assert.equal(d.hit,false);assert.equal(d.reason,'angle');
});
test('rejeita alvo além da distância de ataque',()=>{
 const m=EVENTOS.Morder[0];
 const d=checkContact({origin:{x:0,y:.65,z:.22},target:{x:0,y:.65,z:3},center:{x:0,y:0,z:0},forward:{x:0,y:0,z:1},radius:m.radius,targetRadius:.24,maxDistance:m.maxDistance,coneDeg:m.coneDeg});
 assert.equal(d.hit,false);assert.equal(d.reason,'range');
});
test('registra grupos de repetição e 11 clipes',()=>{
 assert.deepEqual([...LOOPS].sort(),['Andar','Correr','Parado','Procurar'].sort());
 assert.ok(EVENTOS.Agarrar.some(e=>e.type==='pull_target'));
});
