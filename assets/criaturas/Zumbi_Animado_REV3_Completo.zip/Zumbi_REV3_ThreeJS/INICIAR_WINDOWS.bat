@echo off
setlocal
cd /d "%~dp0"
set "PAGE=http://127.0.0.1:8765/"
where node >nul 2>&1
if not errorlevel 1 (
  start "" "%PAGE%"
  node servidor_local.cjs
  goto FIM
)
where py >nul 2>&1
if not errorlevel 1 (
  start "" "%PAGE%"
  py -3 -m http.server 8765 --bind 127.0.0.1
  goto FIM
)
where python >nul 2>&1
if not errorlevel 1 (
  start "" "%PAGE%"
  python -m http.server 8765 --bind 127.0.0.1
  goto FIM
)
echo ERRO: Instale Node.js ou Python 3, ou publique esta pasta no GitHub Pages.
:FIM
echo.
echo Se aparecer um erro acima, copie o texto para facilitar a analise.
pause
