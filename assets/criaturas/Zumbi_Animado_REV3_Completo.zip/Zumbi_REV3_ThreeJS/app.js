import * as THREE from 'three';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {carregarZumbi, ZumbiController} from './ZumbiController_REV3.js';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';

const $=id=>document.getElementById(id);
const names=['Parado','Andar','Correr','Procurar','Morder','Agarrar','Atacar','Dano','Tropecar','Morrer','Levantar'];
const icons=['🧟','🚶','🏃','👀','🦷','🫴','👊','💥','🤕','💀','⬆️'];
const buttons=new Map();let zombie=null;let paused=false;let rotateTarget=false;let speed=1;
let bannerTimer=0;
const clock=new THREE.Clock();
function msg(text){$('status').textContent=text;}
function eventLog(text){
 const el=document.createElement('div');el.textContent=text;
 $('events').prepend(el);while($('events').children.length>9)$('events').lastElementChild.remove();
}
function banner(text,kind=''){
 $('banner').textContent=text;$('banner').className='banner show '+kind;
 bannerTimer=2.0;
}
const stage=$('stage');
const scene=new THREE.Scene();scene.background=new THREE.Color(0x111e22);
scene.fog=new THREE.FogExp2(0x111e22,.035);
const camera=new THREE.PerspectiveCamera(42,1,.025,50);camera.position.set(2.7,1.0,3.5);
const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio||1,2));renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.37;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;stage.prepend(renderer.domElement);
const orbit=new OrbitControls(camera,renderer.domElement);orbit.enableDamping=true;orbit.target.set(0,0,.32);
orbit.minDistance=1.2;orbit.maxDistance=8;orbit.maxPolarAngle=Math.PI*.87;
scene.add(new THREE.HemisphereLight(0xe2fcfd,0x344840,2));
const sun=new THREE.DirectionalLight(0xffead3,3.1);sun.position.set(2.3,4.5,4.2);sun.castShadow=true;
sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-3;sun.shadow.camera.right=3;sun.shadow.camera.top=3;sun.shadow.camera.bottom=-3;
scene.add(sun);const blue=new THREE.DirectionalLight(0x82cce6,1.4);blue.position.set(-3,2,-1);scene.add(blue);
const ground=new THREE.Mesh(new THREE.PlaneGeometry(30,30),new THREE.MeshStandardMaterial({color:0x354642,roughness:1}));ground.rotation.x=-Math.PI/2;ground.position.y=-.95;ground.receiveShadow=true;scene.add(ground);
const grid=new THREE.GridHelper(10,20,0x536b6c,0x3c5554);grid.position.y=-.948;scene.add(grid);

// Target shown alongside actual hit testing, with different head and torso radii.
const dummy=new THREE.Group();dummy.position.set(.07,0,.7);dummy.name='Alvo de Treino';scene.add(dummy);
function bodyGeo(geometry,color,x,y,z){
 const mesh=new THREE.Mesh(geometry,new THREE.MeshStandardMaterial({color,roughness:.72,metalness:.03}));
 mesh.position.set(x,y,z);mesh.castShadow=true;dummy.add(mesh);return mesh;
}
bodyGeo(new THREE.CapsuleGeometry(.23,.64,8,14),0x9eafa1,0,-.24,0);
bodyGeo(new THREE.SphereGeometry(.22,18,14),0xc8c1a8,0,.64,0);
bodyGeo(new THREE.CapsuleGeometry(.088,.58,5,8),0x7e9891,-.18,-.66,0);
bodyGeo(new THREE.CapsuleGeometry(.088,.58,5,8),0x7e9891,.18,-.66,0);
bodyGeo(new THREE.CapsuleGeometry(.073,.42,5,8),0x9eafa1,-.32,-.15,0);
bodyGeo(new THREE.CapsuleGeometry(.073,.42,5,8),0x9eafa1,.32,-.15,0);
const ring=new THREE.Mesh(new THREE.TorusGeometry(.28,.012,7,40),new THREE.MeshBasicMaterial({color:0x81daca}));ring.position.y=-.92;ring.rotation.x=Math.PI/2;dummy.add(ring);
const hpBack=new THREE.Mesh(new THREE.BoxGeometry(.56,.04,.025),new THREE.MeshBasicMaterial({color:0x202e32}));hpBack.position.y=1.05;dummy.add(hpBack);
const hpFront=new THREE.Mesh(new THREE.BoxGeometry(.55,.032,.03),new THREE.MeshBasicMaterial({color:0x64dcb4}));hpFront.position.set(0,1.05,.02);dummy.add(hpFront);
const target={object:dummy,health:100,headRadius:.24,bodyRadius:.36,pullable:true,
 takeDamage(damage,type){
  const pct=Math.max(0,this.health/100);
  hpFront.scale.x=Math.max(.001,pct);hpFront.position.x=-(1-pct)*.275;
  hpFront.material.color.setHex(pct>.35?0x64dcb4:0xff895f);
  $('hp').textContent=`ALVO: ${this.health} / 100`;
  if(this.health===0)banner('ALVO DERROTADO • REINICIE O TESTE','hit');
 }};

const hitMat=new THREE.MeshBasicMaterial({color:0xe5d062,transparent:true,opacity:.28,wireframe:true,depthTest:false});
const hitDebug={};for(const type of ['bite','grab','attack']){
 const s=new THREE.Mesh(new THREE.SphereGeometry(1,16,10),hitMat.clone());s.visible=false;s.renderOrder=10;scene.add(s);hitDebug[type]=s;
}
function debugDraw(){
 const show=$('debug').checked&&zombie;
 const arr=[['bite','Jaw',.43],['grab','R_Hand',.61],['attack','R_Hand',.61]];
 for(const [n,bone,rad] of arr){
  const m=hitDebug[n];m.visible=!!show;if(!show)continue;
  if(n==='grab'&&zombie.bones.has('L_Hand')&&zombie.bones.has('R_Hand')){
   zombie.bones.get('L_Hand').getWorldPosition(m.position);
   const v=new THREE.Vector3();zombie.bones.get('R_Hand').getWorldPosition(v);m.position.add(v).multiplyScalar(.5);
  }else zombie.bones.get(bone)?.getWorldPosition(m.position);
  m.scale.setScalar(rad);
 }
}
function play(name){
 if(!zombie)return;
 const worked=names.indexOf(name)<4?zombie.setLocomotion(name):zombie.play(name);
 if(!worked){banner(name==='Levantar'?'Use levantar após morrer':'Movimento bloqueado pela ação atual','miss');return;}
 for(const [k,el] of buttons)el.classList.toggle('active',k===name);
}
function install(gltf){
 if(zombie)zombie.remove();
 zombie=new ZumbiController(scene,gltf,{
  onState(e){for(const [k,el] of buttons)el.classList.toggle('active',k===e.name);updateStatus();},
  onEvent(e){
   const messages={bite_hit:'🦷 Mordida',grab_attempt:'🫴 Agarrão',attack_hit:'👊 Golpe',pull_target:'↢ Puxão',footstep:'👣 Passo',body_impact:'💀 Queda no chão',standing_up:'⬆ Levantou'};
   if(e.type==='footstep'&&!$('debug').checked)return;
   const label=messages[e.type]||e.type;
   if(['bite_hit','grab_attempt','attack_hit','pull_target'].includes(e.type)){
    banner(e.hit?`${label}: ACERTOU (-${e.damage} HP)`:`${label}: ERROU (${e.reason||'sem agarrão'})`,e.hit?'hit':'miss');
   }
   eventLog(`${e.time.toFixed(2)}s ${label}${e.hit?' | HIT':' | '+(e.reason||'evento')}`);
   updateStatus();
  },
  onHit(e){if(e.type==='grab_attempt')eventLog('Vítima presa: próximo evento poderá puxar')}
 });
 zombie.setTarget(target);zombie.setSpeed(speed);
 $('status').textContent='GLB REV3 carregado com sucesso';
 names.forEach(n=>{buttons.get(n).disabled=!zombie.hasClip(n)});
 updateStatus();eventLog(`${gltf.animations.length} animações incorporadas ao GLB`);
}
function updateStatus(){
 if(!zombie)return;
 msg(`Animação: ${zombie.currentName} (${zombie.clips.get(zombie.currentName)?.duration.toFixed(2)} s)\nEstado: ${zombie.dead?'morto / recuperação':zombie.locked?'executando ação':'livre'}\nClipes: ${zombie.clips.size} · Vida do alvo: ${target.health}/100`);
}
for(const [i,n] of names.entries()){
 const el=document.createElement('button');el.type='button';el.disabled=true;el.textContent=icons[i]+' '+n;
 el.addEventListener('click',()=>play(n));$('buttons').append(el);buttons.set(n,el);
}
async function autoLoad(){
 if(location.protocol==='file:'){msg('Selecione o GLB usando o botão abaixo (modo arquivo local).');return;}
 try { const gltf=await new GLTFLoader().loadAsync('./Zumbi_Animado_REV3.glb');install(gltf); }
 catch(e){msg('Falha ao carregar GLB: '+(e.message||e));console.error(e)}
}
$('file').addEventListener('change',async e=>{
 const f=e.target.files?.[0];if(!f)return;
 const url=URL.createObjectURL(f);
 try{msg('Lendo GLB…');install(await new GLTFLoader().loadAsync(url));}
 catch(ex){msg('Erro: '+(ex.message||ex));}
 finally{URL.revokeObjectURL(url)}
});
$('distance').addEventListener('input',e=>{
 const dist=Number(e.target.value);dummy.position.z=dist;
 $('distanceText').textContent=dist.toFixed(2).replace('.',',')+' m';
});
$('resetTarget').addEventListener('click',()=>{
 target.health=100;target.takeDamage(0,'reset');dummy.position.set(.07,0,Number($('distance').value));
 banner('Alvo restaurado');eventLog('Alvo restaurado para 100 HP');updateStatus();
});
$('revive').addEventListener('click',()=>{
 if(!zombie)return;
 if(!zombie.dead)banner('O zumbi precisa cair antes de levantar','miss');
 else zombie.play('Levantar');
});
$('pause').addEventListener('click',()=>{
 if(!zombie)return;paused=!paused;zombie.paused=paused;$('pause').textContent=paused?'▶ Continuar':'⏸ Pausar';
});
$('speed').addEventListener('input',e=>{
 speed=Number(e.target.value);$('speedText').textContent=speed.toFixed(2).replace('.',',')+'×';zombie?.setSpeed(speed);
});
$('front').addEventListener('click',()=>{camera.position.set(0,.1,3.65);orbit.target.set(0,0,.35);orbit.update()});
$('side').addEventListener('click',()=>{camera.position.set(3.7,.2,.3);orbit.target.set(0,0,.3);orbit.update()});
$('rotate').addEventListener('change',e=>{rotateTarget=e.target.checked});
window.addEventListener('keydown',e=>{
 if(e.target instanceof HTMLInputElement)return;
 const i=Number(e.key)-1;if(i>=0&&i<9)play(names[i]);
 if(e.key==='0')play('Morrer');if(e.key==='-')play('Levantar');
 if(e.key===' '){e.preventDefault();$('pause').click()}
});
const observer=new ResizeObserver(()=>{
 const w=stage.clientWidth,h=stage.clientHeight;
 camera.aspect=w/Math.max(1,h);camera.updateProjectionMatrix();renderer.setSize(w,h,false);
});observer.observe(stage);
renderer.setAnimationLoop(()=>{
 const dt=Math.min(clock.getDelta(),.05);if(!paused){zombie?.update(dt);if(rotateTarget)dummy.rotation.y+=dt*.27;}
 if(bannerTimer>0){bannerTimer-=dt;if(bannerTimer<=0)$('banner').classList.remove('show');}
 debugDraw();orbit.update();renderer.render(scene,camera);
});
autoLoad();
