/**
 * Pure combat math and contact schedule: can be unit tested without Three.js.
 * Units: meters in normalized source GLB scale; forward direction: +Z.
 */
export const LOOPS = new Set(['Parado', 'Andar', 'Correr', 'Procurar']);
export const EVENTOS = Object.freeze({
  Andar:[{time:.16,type:'footstep',foot:'L'},{time:.94,type:'footstep',foot:'R'}],
  Correr:[{time:.10,type:'footstep',foot:'L'},{time:.53,type:'footstep',foot:'R'}],
  Morder:[{time:.56,type:'bite_hit',damage:22,maxDistance:1.10,coneDeg:95,radius:.43}],
  Agarrar:[{time:.85,type:'grab_attempt',damage:6,maxDistance:1.20,coneDeg:105,radius:.61},
           {time:1.18,type:'pull_target',damage:4}],
  Atacar:[{time:.44,type:'attack_hit',damage:14,maxDistance:1.25,coneDeg:110,radius:.61}],
  Morrer:[{time:1.02,type:'body_impact'}],
  Levantar:[{time:2.20,type:'standing_up'}]
});

/** Handles a wrap around the loop boundary (previous position near end -> new near zero). */
export function crossedEvents(markers,previous,current,duration,isLoop=false){
  if(!markers?.length || !Number.isFinite(duration)||duration<=0)return [];
  const last=Math.min(duration,Math.max(-.001,previous));
  const next=Math.min(duration,Math.max(0,current));
  if(next>=last) return markers.filter(x=>x.time>last&&x.time<=next);
  return isLoop ? markers.filter(x=>x.time>last||x.time<=next):[];
}

/** World-space sphere-vs-sphere plus distance and forward-facing cone. */
export function checkContact({origin,target,center,forward,maxDistance,coneDeg,radius,targetRadius}){
  if([origin,target,center,forward].some(v=>!v||!Number.isFinite(v.x+v.y+v.z)))return {hit:false,reason:'invalid'};
  const hx=target.x-center.x,hz=target.z-center.z;
  const horizontal=Math.hypot(hx,hz);
  const fx=forward.x,fz=forward.z;
  const forwardLen=Math.hypot(fx,fz)||1;
  const dot=horizontal<1e-6?1:(hx*fx+hz*fz)/(horizontal*forwardLen);
  const alignment=Math.max(-1,Math.min(1,dot));
  if(horizontal>maxDistance+targetRadius)return {hit:false,reason:'range',distance:horizontal};
  if(alignment<Math.cos((coneDeg/2)*Math.PI/180))return {hit:false,reason:'angle',distance:horizontal};
  const d=Math.hypot(origin.x-target.x,origin.y-target.y,origin.z-target.z);
  if(d>radius+targetRadius)return {hit:false,reason:'contact',distance:d};
  return {hit:true,reason:'ok',distance:d};
}
