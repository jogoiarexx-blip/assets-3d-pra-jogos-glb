"""Software point-splat rendering from the actual skinned GLB (not an invented illustration)."""
import json,struct,io
import numpy as np
from scipy.spatial.transform import Rotation
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
root=Path(__file__).parent
f=open(root/'Zumbi_Animado_REV3.glb','rb');f.read(12)
l,k=struct.unpack('<II',f.read(8));g=json.loads(f.read(l));l,k=struct.unpack('<II',f.read(8));blob=f.read(l)
TYPE={5126:np.float32,5125:np.uint32,5123:np.uint16}
SIZES={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4,'MAT4':16}
def a(idx):
 o=g['accessors'][idx];b=g['bufferViews'][o['bufferView']]
 arr=np.frombuffer(blob,dtype=TYPE[o['componentType']],count=o['count']*SIZES[o['type']],offset=b.get('byteOffset',0)+o.get('byteOffset',0)).reshape(-1,SIZES[o['type']])
 return arr
prim=g['meshes'][0]['primitives'][0]['attributes']
vertices=a(prim['POSITION']).astype(np.float32)
uv=a(prim['TEXCOORD_0']).astype(np.float32)
joints=a(prim['JOINTS_0']).astype(np.int32)
weights=a(prim['WEIGHTS_0']).astype(np.float32)
IB=a(g['skins'][0]['inverseBindMatrices']).reshape(-1,4,4).transpose(0,2,1).copy()
imgid=g['images'][0]['bufferView'];bv=g['bufferViews'][imgid];data=blob[bv['byteOffset']:bv['byteOffset']+bv['byteLength']]
tex=np.asarray(Image.open(io.BytesIO(data)).convert('RGB'))
uh=np.clip((uv[:,0]*(tex.shape[1]-1)).astype(int),0,tex.shape[1]-1)
vh=np.clip(((1-uv[:,1])*(tex.shape[0]-1)).astype(int),0,tex.shape[0]-1)
colors=tex[vh,uh]
# subtle ambient light retained from the actual texture
colors=np.clip(colors.astype(float)*.92+13,0,255).astype('uint8')
parents={}
for i,node in enumerate(g['nodes']):
 for child in node.get('children',[]):parents[child]=i
nodes={n.get('name'):i for i,n in enumerate(g['nodes'])}

def get_pose(name,t):
 anim=next(x for x in g['animations'] if x['name']==name)
 vals={}
 for channel in anim['channels']:
  smp=anim['samplers'][channel['sampler']];times=a(smp['input'])[:,0];arr=a(smp['output'])
  i=max(0,min(len(times)-2,int(np.searchsorted(times,t,'right')-1)))
  ratio=(t-times[i])/(times[i+1]-times[i])
  v=arr[i]*(1-ratio)+arr[i+1]*ratio
  if channel['target']['path']=='rotation':v=v/np.linalg.norm(v)
  vals[(channel['target']['node'],channel['target']['path'])]=v
 matrices={}
 for idx,node in enumerate(g['nodes']):
  xyz=vals.get((idx,'translation'),node.get('translation',[0,0,0]))
  quaternion=vals.get((idx,'rotation'),node.get('rotation',[0,0,0,1]))
  mat=np.eye(4)
  mat[:3,:3]=Rotation.from_quat(quaternion).as_matrix()
  mat[:3,3]=xyz
  parent=parents.get(idx)
  matrices[idx]=matrices[parent]@mat if parent is not None else mat
 palette=np.stack([matrices[n]@IB[i] for i,n in enumerate(g['skins'][0]['joints'])]).astype('float32')
 v4=np.column_stack([vertices,np.ones((len(vertices),),dtype='float32')])
 transformed=np.zeros_like(vertices)
 for i in range(4):
  mats=palette[joints[:,i]]
  transformed+=np.einsum('nij,nj->ni',mats,v4,optimize=True)[:,:3]*weights[:,i:i+1]
 return transformed

W,H=440,580
fig=Image.new('RGB',(W*3,H),(11,24,29))
font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',22)
small=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13)
for j,(name,t) in enumerate([('Procurar',.82),('Tropecar',.66),('Levantar',1.65)]):
 pts=get_pose(name,t)
 canvas=Image.new('RGB',(W,H),(19,37,43));d=ImageDraw.Draw(canvas)
 d.line((0,502,W,502),fill=(74,100,99),width=2)
 d.text((18,20),name.upper(),font=font,fill=(230,242,238))
 d.text((18,56),'Pose amostrada diretamente do GLB',font=small,fill=(142,182,181))
 scale=244
 X=(W/2+pts[:,0]*scale).astype(int)
 Y=(275-pts[:,1]*scale).astype(int)
 # glTF frontal viewing camera at +Z. Draw farther points first.
 for ix in np.argsort(pts[:,2]):
  x=int(X[ix]);y=int(Y[ix]);
  if x<-2 or x>W+2 or y<77 or y>=503:continue
  col=tuple(colors[ix]);d.ellipse((x-1,y-1,x+1,y+1),fill=col)
 d.text((18,538),f't = {t:.2f}s · 22 ossos',font=small,fill=(140,193,181))
 fig.paste(canvas,(j*W,0))
p= root/'preview_REV3_novos_movimentos.png'
fig.save(p,optimize=True)
print('preview salvo',p,p.stat().st_size)
