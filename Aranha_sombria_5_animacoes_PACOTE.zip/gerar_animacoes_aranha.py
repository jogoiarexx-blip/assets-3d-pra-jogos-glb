#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Adiciona Idle, Walk, Jump, Attack e WebShot a uma aranha GLB que possua o rig SmartRig de 72 ossos.
Dependencias: numpy, scipy. Executar: python gerar_animacoes_aranha.py 'Aranha sombria.glb' 'Aranha_sombria_animada.glb'
Preserva as malhas/texturas/pesos originais; gera a teia como malha independente animada.
"""
import json, math, struct, sys, copy
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation as Rot

SRC=Path(sys.argv[1] if len(sys.argv)>1 else 'Aranha sombria.glb')
OUT=Path(sys.argv[2] if len(sys.argv)>2 else 'Aranha_sombria_animada.glb')
with SRC.open('rb') as f:
    magic,version,size=struct.unpack('<4sII',f.read(12))
    assert magic==b'glTF' and version==2
    jl,jtype=struct.unpack('<I4s',f.read(8)); gltf=json.loads(f.read(jl))
    bl,btype=struct.unpack('<I4s',f.read(8)); assert btype==b'BIN\x00'
    bindata=bytearray(f.read(bl))

nodes=gltf['nodes']
assert len(gltf['skins'])==1 and len(gltf['skins'][0]['joints'])==72
names={n.get('name'):i for i,n in enumerate(nodes)}
assert names.get('Bone_000')==71 and names.get('Bone_032')==28, 'Rig diferente, abortado para não deformar outro personagem'
parents={c:i for i,n in enumerate(nodes) for c in n.get('children',[])}

def localm(n):
    m=np.eye(4)
    if 'matrix' in n:
        return np.asarray(n['matrix'],dtype=float).reshape((4,4),order='F')
    m[:3,:3]=Rot.from_quat(n.get('rotation',[0,0,0,1])).as_matrix()@np.diag(n.get('scale',[1,1,1]))
    m[:3,3]=n.get('translation',[0,0,0]);return m
local=[localm(n) for n in nodes]
worldcache={}
def world(i):
    if i not in worldcache:worldcache[i]=(world(parents[i])@local[i]) if i in parents else local[i]
    return worldcache[i]
worldquat=[]
for i in range(len(nodes)):
    mat=world(i)[:3,:3]
    # Remove tiny Blender floating point scale artifacts before quaternion conversion.
    u,s,vh=np.linalg.svd(mat);r=u@vh
    worldquat.append(Rot.from_matrix(r))
restrot={i:Rot.from_quat(n.get('rotation',[0,0,0,1])) for i,n in enumerate(nodes)}
resttr={i:np.array(n.get('translation',[0,0,0]),dtype=float) for i,n in enumerate(nodes)}
restsc={i:np.array(n.get('scale',[1,1,1]),dtype=float) for i,n in enumerate(nodes)}

def smooth(x):
    x=np.clip(x,0,1);return x*x*(3-2*x)
def easing(t,knots):
    if t<=knots[0][0]:return knots[0][1]
    for (a,va),(b,vb) in zip(knots,knots[1:]):
        if t<=b:
            q=smooth((t-a)/(b-a));return va*(1-q)+vb*q
    return knots[-1][1]
def curve(t,seq):return easing(t,seq)

def euler_world(i, xyz=(0,0,0)):
    # Delta expressed in rest-pose world coordinates, transformed to the node's parent axes.
    delta=Rot.from_euler('xyz',xyz)
    parent=worldquat[parents[i]] if i in parents else Rot.identity()
    return (parent.inv()*delta*parent*restrot[i]).as_quat()

def qpose(worldrot):
    return {idx:euler_world(idx,angles) for idx,angles in worldrot.items()}

# 4 pairs ordered anterior (+Z) to posterior (-Z), each left and right.
LEGS=[
    ([(22,21,20,19,18),(27,26,25,24,23)]),
    ([(34,33,32,31,30),(46,45,44,43,42)]),
    ([(51,50,49,48,47),(39,38,37,36,35)]),
    ([(63,62,61,60,59),(58,57,56,55,54)]),
]
leg_nodes={n for pair in LEGS for chain in pair for n in chain}
channels_nodes=set(leg_nodes)|{71,70,69,65,64,52,40,28,3,7,11,16,12,17}
clips=[('Idle',3.,30),('Walk',1.20,40),('Jump',1.60,50),('Attack',1.12,50),('WebShot',1.45,50)]

def pose(name,t,d):
    phase=t/d
    turn={}; trans={}; scales={}
    base=resttr[71].copy()
    if name=='Idle':
        a=2*math.pi*phase
        base[1]+=.008*math.sin(a)+.003*math.sin(a*2)
        turn[71]=(.009*math.sin(a-.4),.012*math.sin(a*.5),.006*math.sin(a))
        turn[69]=(.035*math.sin(a),.01*math.sin(a),.008*math.sin(a))
        scales[69]=restsc[69]*np.array([1+.010*math.sin(a),1+.012*math.sin(a),1+.012*math.sin(a)])
        turn[28]=(-.025*math.sin(a+.4),0,.015*math.sin(a*.5))
        for k,pair in enumerate(LEGS):
            for side,chain in zip((-1,1),pair):
                b=2*math.pi*(phase+(.09*k)+.20*(side==1))
                turn[chain[0]]=(.008*math.sin(b),side*.014*math.sin(b),side*.011*math.cos(b))
                turn[chain[1]]=(0,0,side*.010*math.sin(b+.7))
                turn[chain[2]]=(0,0,side*.005*math.cos(b+.5))
        trans[71]=base
    elif name=='Walk':
        a=2*math.pi*phase
        base[0]+=.020*math.sin(a)
        base[1]+=.016*(1+math.sin(a*2))
        turn[71]=(.022+.016*math.sin(a*2),.014*math.sin(a),-.021*math.sin(a))
        turn[69]=(.024*math.sin(a-.5),.016*math.sin(a),.014*math.sin(a))
        turn[28]=(-.014+.022*math.sin(a),.012*math.sin(a),0)
        for k,pair in enumerate(LEGS):
            for si,(side,chain) in enumerate(zip((-1,1),pair)):
                # Diagonally alternating gait: each leg swings forward during recovery.
                p=(phase+((k+si)%2)*.5)%1
                lifter=max(0.,math.sin(math.pi*min(1,p/.43))) if p<.43 else 0.
                yaw=side*(.245*math.cos(2*math.pi*p))
                lift=side*(.125*lifter+.006*math.sin(2*math.pi*p))
                turn[chain[0]]=(.025*math.sin(2*math.pi*p),yaw,0.43*lift)
                turn[chain[1]]=(0.,-.18*yaw,.80*lift)
                turn[chain[2]]=(0.,.12*yaw,-.25*lift)
                turn[chain[3]]=(0.,0.,.45*lift)
                turn[chain[4]]=(0.,0.,.16*lift)
        trans[71]=base
    elif name=='Jump':
        # Anticipation, takeoff, flight apex, landing, settle. In place for engine root-motion control.
        jump=curve(t,[(0,0),(.22,-.045),(.38,.17),(.77,.73),(1.05,.34),(1.30,-.025),(1.50,0),(d,0)])
        tuck=curve(t,[(0,0),(.20,.25),(.42,.75),(.70,1),(.97,.83),(1.23,0),(1.5,0),(d,0)])
        launch=curve(t,[(0,0),(.20,-.075),(.38,.10),(.83,.03),(1.27,-.08),(d,0)])
        base[1]+=jump
        turn[71]=(-.085*tuck+.050*(t/.5)*(t<.5),0,.024*math.sin(2*math.pi*phase))
        turn[69]=(-.055*tuck,0,0)
        turn[28]=(.045*tuck,0,0)
        for k,pair in enumerate(LEGS):
            for side,chain in zip((-1,1),pair):
                turn[chain[0]]=(0,side*(-.065*tuck),side*(.16*tuck-.04*launch))
                turn[chain[1]]=(0,0,side*(-.25*tuck+.10*launch))
                turn[chain[2]]=(0,0,side*(.19*tuck-.05*launch))
                turn[chain[3]]=(0,0,side*(-.08*tuck))
        trans[71]=base
    elif name=='Attack':
        prep=curve(t,[(0,0),(.17,1),(.37,1),(.51,.14),(.68,0),(d,0)])
        strike=curve(t,[(0,0),(.30,0),(.48,1),(.59,.85),(.84,0),(d,0)])
        base[1]+=-.025*prep+.085*strike
        base[2]+=-.065*prep+.19*strike
        turn[71]=(-.06*prep+.05*strike,0,.018*math.sin(math.pi*phase))
        turn[69]=(.055*prep-.10*strike,0,0)
        turn[28]=(-.07*prep+.06*strike,0,0)
        for k,pair in enumerate(LEGS):
            for side,chain in zip((-1,1),pair):
                f=1 if k==0 else (.24 if k==1 else .07)
                turn[chain[0]]=(-.09*strike*f,side*(-.27*strike*f),side*(.26*prep*f+.035*strike*f))
                turn[chain[1]]=(.06*strike*f,0,side*(.28*prep*f-.045*strike*f))
                turn[chain[2]]=(0,0,side*(-.11*prep*f+.25*strike*f))
                turn[chain[3]]=(0,0,side*(.08*strike*f))
        # Forefangs clamp in a short timed bite.
        for si,n in enumerate((3,7,11,16,12,17)):
            side=(-1 if si%2==0 else 1)
            turn[n]=(.06*prep-.16*strike,side*.11*strike,side*.07*strike)
        trans[71]=base
    elif name=='WebShot':
        prep=curve(t,[(0,0),(.23,1),(.40,1),(.57,.2),(.70,0),(d,0)])
        release=curve(t,[(0,0),(.36,0),(.49,1),(.65,.7),(.90,0),(d,0)])
        base[2]+=-.085*prep+.11*release
        base[1]+=.045*prep+.055*release
        turn[71]=(-.03*prep+.04*release,0,.010*math.sin(6*math.pi*phase)*release)
        turn[69]=(.09*prep-.13*release,0,0)
        turn[28]=(-.17*prep+.15*release,0,0)
        for k,pair in enumerate(LEGS):
            for side,chain in zip((-1,1),pair):
                f=1 if k==0 else .17
                turn[chain[0]]=(0,side*(-.10*prep*f),side*(.12*prep*f+.08*release*f))
                turn[chain[1]]=(0,0,side*(.10*prep*f+.10*release*f))
        trans[71]=base
    return turn,trans,scales

# Generate silk accessory as normal unskinned, child of head bone so it follows attack movement.
def put_bytes(b,target=None):
    while len(bindata)%4:bindata.append(0)
    offset=len(bindata);bindata.extend(b)
    view={'buffer':0,'byteOffset':offset,'byteLength':len(b)}
    if target:view['target']=target
    gltf['bufferViews'].append(view)
    return len(gltf['bufferViews'])-1

def accessor(vals,typ,comp=5126,target=None,with_bounds=False):
    dtype={5126:'<f4',5123:'<u2',5125:'<u4'}[comp]
    arr=np.asarray(vals,dtype=dtype)
    arr=arr.reshape(-1,{'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[typ])
    vid=put_bytes(arr.tobytes(),target)
    a={'bufferView':vid,'componentType':comp,'count':len(arr),'type':typ}
    if with_bounds:a.update(min=[float(x) for x in arr.min(axis=0)],max=[float(x) for x in arr.max(axis=0)])
    gltf['accessors'].append(a);return len(gltf['accessors'])-1

# Light segmented tubular silk: forward axis is +Z.
webverts=[];webind=[]
def add_tube(points,r,ns=6):
    global webverts,webind
    points=np.asarray(points,dtype=float)
    start=len(webverts)
    for i,p in enumerate(points):
        tangent=points[min(len(points)-1,i+1)]-points[max(0,i-1)]
        tangent=tangent/max(np.linalg.norm(tangent),1e-9)
        u=np.cross(tangent, [0,1,0]);
        if np.linalg.norm(u)<1e-6:u=np.cross(tangent,[1,0,0])
        u=u/np.linalg.norm(u);v=np.cross(tangent,u)
        for j in range(ns):
            ang=2*math.pi*j/ns
            webverts.append((p+r*(math.cos(ang)*u+math.sin(ang)*v)).tolist())
    for i in range(len(points)-1):
        for j in range(ns):
            a=start+i*ns+j;b=start+i*ns+(j+1)%ns;c=b+ns;d=a+ns
            webind.extend([a,b,d,b,c,d])

def save_mesh(label):
    # index ushort for compact decorative meshes
    posidx=accessor(webverts,'VEC3',target=34962,with_bounds=True)
    indices=accessor(webind,'SCALAR',comp=5123 if len(webverts)<65536 else 5125,target=34963)
    m={'name':label,'primitives':[{'attributes':{'POSITION':posidx},'indices':indices,'material':len(gltf['materials'])-1,'mode':4}]}
    gltf['meshes'].append(m)
    webverts.clear();webind.clear()
    return len(gltf['meshes'])-1

silk_mat={'name':'Teia_seda_prateada','pbrMetallicRoughness':{'baseColorFactor':[.82,.94,1,1], 'metallicFactor':.0,'roughnessFactor':.28},'emissiveFactor':[.18,.25,.28],'doubleSided':True}
silk_mat['extensions']={'KHR_materials_unlit':{}}
gltf.setdefault('extensionsUsed',[]).append('KHR_materials_unlit')
gltf['materials'].append(silk_mat)
# Silky 3-line braided filament, spans z=0 to z=1 then scaled by animated Z.
for offset in (0,2*math.pi/3,4*math.pi/3):
    add_tube([[.018*math.cos(8*math.pi*i/32+offset),.018*math.sin(8*math.pi*i/32+offset),i/32] for i in range(33)],.010,5)
fil_mesh=save_mesh('Teia_Filamento_Mesh')
# Projectile: stylized 12-spoke conical expanding web, circular rings and reinforced knots.
for spoke in range(12):
    a=spoke*2*math.pi/12
    add_tube([[0,0,-.045],[.13*math.cos(a),.13*math.sin(a),0],[.26*math.cos(a),.26*math.sin(a),.04]],.009,5)
for radius in (.085,.15,.22,.27):
    add_tube([[radius*math.cos(2*math.pi*i/48),radius*math.sin(2*math.pi*i/48),.042*radius/.27] for i in range(49)],.007,5)
net_mesh=save_mesh('Teia_Projetil_Mesh')

# Child transform positions mouth anchor at center front of cephalothorax (world rest space).
head=28;anchor=np.array([.0,.70,1.12,1.0]);inv=np.linalg.inv(world(head));emitter_pos=(inv@anchor)[:3]
emitter_rot=worldquat[head].inv().as_quat()

nodes.append({'name':'Teia_Emissor_Boca','translation':emitter_pos.tolist(),'rotation':emitter_rot.tolist(),'children':[len(nodes)+1,len(nodes)+2]})
emitter=len(nodes)-1
nodes.append({'name':'Teia_Filamento','mesh':fil_mesh,'scale':[.0001,.0001,.0001]})
filnode=len(nodes)-1
nodes.append({'name':'Teia_Projetil','mesh':net_mesh,'scale':[.0001,.0001,.0001]})
netnode=len(nodes)-1
nodes[head].setdefault('children',[]).append(emitter)

# Sample pose and create rotation channels for every animated joint; scale tracks hide silk in non-WebShot clips.
for name,duration,fps in clips:
    count=int(round(duration*fps))+1
    times=np.linspace(0,duration,count,dtype=np.float32)
    time_acc=accessor(times,'SCALAR',with_bounds=True)
    allrot={i:[] for i in sorted(channels_nodes)}
    alltr={71:[]}
    allsc={69:[],filnode:[],netnode:[]}
    nett=[]
    for t in times:
        tt=float(t)
        turn,tr,scale=pose(name,tt,duration)
        for i in allrot:allrot[i].append(euler_world(i,turn.get(i,(0,0,0))))
        for i in alltr:alltr[i].append(tr.get(i,resttr[i]).tolist())
        allsc[69].append(scale.get(69,restsc[69]).tolist())
        if name=='WebShot':
            # Teia aparece quando cabeça estica, viaja para frente, depois se recolhe/desaparece.
            width=curve(tt,[(0,0),(.40,0),(.51,.84),(.65,1),(.95,1),(1.10,.0),(duration,0)])
            length=curve(tt,[(0,0),(.40,0),(.57,.65),(.78,2.5),(.94,3.1),(1.10,0),(duration,0)])
            fil_s=[max(.0001,width),max(.0001,width),max(.0001,length)]
            travel=curve(tt,[(0,0),(.42,0),(.58,.65),(.78,2.5),(.94,3.1),(1.10,3.6),(duration,3.6)])
            webscale=curve(tt,[(0,0),(.43,0),(.58,.45),(.75,.85),(.95,1),(1.10,.1),(1.16,0),(duration,0)])
            sc=max(.0001,webscale)
            allsc[filnode].append(fil_s)
            allsc[netnode].append([sc]*3)
            nett.append([0,0,travel])
        else:
            allsc[filnode].append([.0001]*3)
            allsc[netnode].append([.0001]*3)
            nett.append([0,0,0])
    anim={'name':name,'samplers':[],'channels':[],'extras':{'duration':duration,'fps':fps,'loop':name in ('Idle','Walk'),'description':{'Idle':'Respiracao e micromovimentos das oito patas','Walk':'Marcha alternada de oito patas em ciclo no lugar','Jump':'Agachar, saltar, recolher patas e aterrissar','Attack':'Preparar, erguer patas dianteiras e atacar','WebShot':'Preparacao, disparo visivel de seda e recuperacao'}[name]}}
    def addanim(node,path,values):
        if path=='rotation':
            vals=np.asarray(values,dtype=np.float64)
            # Quaternions q/-q represent same orientation, but discontinuities spoil interpolation.
            for k in range(1,len(vals)):
                if np.dot(vals[k-1],vals[k])<0:vals[k]*=-1
            vals/=np.linalg.norm(vals,axis=1,keepdims=True)
            arr=accessor(vals,'VEC4')
        else:arr=accessor(values,'VEC3')
        anim['samplers'].append({'input':time_acc,'output':arr,'interpolation':'LINEAR'})
        anim['channels'].append({'sampler':len(anim['samplers'])-1,'target':{'node':node,'path':path}})
    for i,vals in allrot.items():addanim(i,'rotation',vals)
    for i,vals in alltr.items():addanim(i,'translation',vals)
    for i,vals in allsc.items():addanim(i,'scale',vals)
    addanim(netnode,'translation',nett)
    gltf.setdefault('animations',[]).append(anim)

# All new mesh/material/node data preserve original primitive, textures and skin.
gltf['buffers'][0]['byteLength']=len(bindata)
while len(bindata)%4:bindata.append(0)
gltf['buffers'][0]['byteLength']=len(bindata)
js=json.dumps(gltf,ensure_ascii=False,separators=(',',':')).encode('utf8')
while len(js)%4:js+=b' '
length=12+8+len(js)+8+len(bindata)
with OUT.open('wb') as f:
    f.write(struct.pack('<4sII',b'glTF',2,length))
    f.write(struct.pack('<I4s',len(js),b'JSON'));f.write(js)
    f.write(struct.pack('<I4s',len(bindata),b'BIN\x00'));f.write(bindata)
print(f'Saved {OUT}: {len(gltf["animations"])} clips, {len(gltf["skins"][0]["joints"])} rig bones, {OUT.stat().st_size/1048576:.2f} MB')
for a in gltf['animations']:print(a['name'],a['extras']['duration'],'s',len(a['channels']),'channels')
